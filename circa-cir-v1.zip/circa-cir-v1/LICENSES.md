# Licensing (per layer)

| Layer | Underlying text | Annotation license | Redistributable text? | Access |
|---|---|---|---|---|
| ACI-Bench (SIMORD) | CC BY 4.0 / CDLA-Permissive-2.0, simulated | CDLA-Permissive-2.0 | Yes | Public |
| CLIP / MedDec / ap_parsing / PaniniQA | MIMIC-III (PhysioNet credentialed DUA) | CIR annotations, open | No (offsets only) | Credentialed via PhysioNet |

The combined resource does NOT carry one uniform license. MIMIC-derived text stays under
the PhysioNet DUA and is never redistributed here; only stand-off annotations and a rebuild
script are shared. A HIPAA BAA on the annotation pipeline is separate from, and does not
substitute for, the source-corpus DUA.
