# CIRCA code: FHIR mapper, source-to-CIR crosswalks, reference evaluator

This directory holds the code released with CIRCA (open license). It is a self-contained
subset of the annotation pipeline: the deterministic FHIR mapper, the source-to-CIR
crosswalks, and the reference benchmark evaluator, with their import closure.

```
backend/cir_to_fhir.py   Deterministic CIR -> FHIR R4 mapper. Serializes a CIR record to a
                         ServiceRequest / MedicationRequest / CarePlan entry; request_intent
                         maps to FHIR RequestIntent and the coded target to the resource.
backend/crosswalk.py     Source-to-CIR crosswalks: proposes a candidate CIR type per source
                         label (CLIP, MedDec, ap_parsing, PaniniQA, SIMORD/ACI-Bench).
backend/schema.py        The CIR schema: fields, the two novel axes (request_intent, modality),
                         and controlled vocabularies.
backend/canonicalize.py  Deterministic normalization (time, polarity, medication verbs, codes),
                         with temporal.py and medlist.py.
backend/config.py, prompt.py   Support modules the evaluator imports.
tools/gold_eval.py       Reference evaluator implementing the Section 6 matching rule
                         (weighted span-token overlap + target + type similarity, threshold
                         0.45, code cannot-link, one-to-one), with dataset loaders.
```

## Run

```bash
# from this code/ directory
python -c "import backend.cir_to_fhir as m; print(m.__doc__)"   # FHIR mapper
python tools/gold_eval.py --help                                # reference evaluator
```

`gold_eval.py` expects the released stand-off annotations (`../credentialed/annotations_cir.jsonl`
and `../public/aci_bench_cir.jsonl`); for the MIMIC layers, rehydrate first with `../rebuild.py`
and your own credentialed MIMIC-III access. Dependencies: `pydantic` (schema). No network access
and no credentials are required to run the mapper or evaluator.
