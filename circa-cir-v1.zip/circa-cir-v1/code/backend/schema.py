"""The Clinical Intent Representation (CIR) — Pydantic models + deterministic
validators. Mirrors labeling-app.html / standards §14. request_intent (FHIR
authority) and modality (clinical strength) are kept as separate axes."""
from __future__ import annotations
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator

# ---- controlled vocabularies -------------------------------------------
ACTION_TYPES = {
    "appointment_followup", "laboratory", "imaging", "procedure",
    "referral_consultation", "medication", "monitoring",
    "therapy_intervention", "patient_instruction", "other",
}
REQUEST_INTENT = {"proposal", "plan", "order", "option"}          # FHIR Request.intent
MODALITY = {"ordered", "recommended", "planned", "considered",
            "conditional", "optional", "prohibited"}
CONDITION_KIND = {"applicability", "start", "stop"}
DEP_REL = {"before", "before-start", "before-end", "concurrent",
           "concurrent-with-start", "concurrent-with-end",
           "after", "after-start", "after-end", "same_encounter"}
FIELD_STATE = {"from_source", "llm_filled", "human_confirmed", "missing"}

MANDATORY_FIELDS = ("action", "type", "target", "provenance")


class Provenance(BaseModel):
    span: str
    role: str = "action"          # action | timing | condition | target | ...
    start_char: Optional[int] = None
    end_char: Optional[int] = None


class Timing(BaseModel):
    text: Optional[str] = None
    normalized: Optional[str] = None       # ISO-8601 duration e.g. P3M
    anchor: Optional[str] = None           # document_date | discharge_date | reference_intent
    kind: Optional[str] = None             # relative_offset | deadline | event_relative | ...
    reference_intent: Optional[str] = None
    min_offset_days: Optional[int] = None
    max_offset_days: Optional[int] = None


class Dependency(BaseModel):
    target_intent: str
    relationship: str = "after"
    offset_days: Optional[int] = None

    @field_validator("relationship")
    @classmethod
    def _rel(cls, v):
        if v not in DEP_REL:
            raise ValueError(f"relationship {v!r} not in {sorted(DEP_REL)}")
        return v


class Condition(BaseModel):
    text: str
    kind: str = "applicability"
    focus: Optional[str] = None

    @field_validator("kind")
    @classmethod
    def _kind(cls, v):
        if v not in CONDITION_KIND:
            raise ValueError(f"condition.kind {v!r} invalid")
        return v


class Intent(BaseModel):
    intent_id: str
    action: str
    type: str
    target: Optional[object] = None          # verbatim str OR dual {text, category, code}
    actor: Optional[str] = None
    time: Optional[Timing] = None
    frequency: Optional[str] = None          # recurrence/dosing (daily, BID) — NOT time
    duration: Optional[str] = None           # how long (for 7 days)
    condition: Optional[Condition] = None
    reason: Optional[str] = None
    goal: Optional[str] = None
    dependency: Optional[list[Dependency]] = None
    request_intent: Optional[str] = None
    modality: Optional[str] = None
    status: Optional[str] = None
    provenance: list[Provenance] = Field(default_factory=list)

    @field_validator("type")
    @classmethod
    def _type(cls, v):
        if v not in ACTION_TYPES:
            raise ValueError(f"type {v!r} not in taxonomy")
        return v

    @field_validator("request_intent")
    @classmethod
    def _ri(cls, v):
        if v is not None and v not in REQUEST_INTENT:
            raise ValueError(f"request_intent {v!r} invalid")
        return v

    @field_validator("modality")
    @classmethod
    def _mod(cls, v):
        if v is not None and v not in MODALITY:
            raise ValueError(f"modality {v!r} invalid")
        return v


_SCALAR_FIELDS = ("actor", "reason", "goal", "status", "frequency", "duration")


def coerce_intent(data: dict) -> dict:
    """Repair common shape mistakes BEFORE validation so a good intent is not dropped
    over a wrapper. Models that learn target={text,category} over-generalize it to
    scalar fields (reason={text,code}) and sometimes emit condition as a bare string.
    Idempotent; leaves already-correct values untouched."""
    if not isinstance(data, dict):
        return data
    d = dict(data)
    for f in _SCALAR_FIELDS:                       # {text: "..."} -> "..."
        v = d.get(f)
        if isinstance(v, dict):
            d[f] = v.get("text") or v.get("category") or v.get("value") or None
    c = d.get("condition")                         # "if X" -> {text: "if X"}
    if isinstance(c, str) and c.strip():
        d["condition"] = {"text": c, "kind": "applicability"}
    return d


def validate_intent(data: dict) -> tuple[bool, list[str]]:
    """Deterministic structural validation (spec V1). Returns (ok, errors)."""
    errors: list[str] = []
    try:
        intent = Intent(**data)
    except Exception as e:
        return False, [str(e)]
    for f in MANDATORY_FIELDS:
        val = getattr(intent, f)
        if val in (None, "", []):
            errors.append(f"mandatory field '{f}' missing")
    # provenance-grounding stub: every provenance span must be non-empty
    for p in intent.provenance:
        if not p.span.strip():
            errors.append("empty provenance span")
    # dependency cannot reference self
    for d in (intent.dependency or []):
        if d.target_intent == intent.intent_id:
            errors.append("intent depends on itself")
    return (len(errors) == 0), errors


def _norm_ws(s: str) -> str:
    return " ".join(s.split())


def check_grounded(intent: dict, source_text: str) -> list[str]:
    """V2 grounding: every provenance span must occur in the source text
    (whitespace-insensitive, since LLMs re-flow spaces/newlines)."""
    problems = []
    src = _norm_ws(source_text)
    for p in intent.get("provenance", []):
        span = _norm_ws(p.get("span") or "")
        if span and span not in src:
            problems.append(f"provenance not found in source: {span[:40]!r}")
    return problems
