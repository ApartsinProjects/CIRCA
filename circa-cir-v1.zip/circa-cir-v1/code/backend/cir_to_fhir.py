"""CIR -> FHIR R4 round-trip. A deterministic mapper from a Clinical Intent Representation
record to a FHIR R4 request resource, validated against the R4 schema via fhir.resources.

Mapping (CIR field -> FHIR element):
  type=medication                      -> MedicationRequest
  type in {laboratory, imaging,        -> ServiceRequest
    procedure, monitoring, therapy,
    appointment_followup, referral}
  type=patient_instruction             -> CommunicationRequest
  request_intent (proposal/plan/order/option) -> .intent   (direct: FHIR RequestIntent)
  target.code {system,code,display}    -> .code / .medicationCodeableConcept (coding)
  target.text/category                 -> .code.text
  time.day_range                       -> .occurrenceTiming.repeat.boundsDuration (days)
  frequency                            -> dosageInstruction.timing (medication)
  modality=prohibited                  -> doNotPerform = true
  modality=optional / PRN condition    -> asNeeded
  action stop/hold                     -> status stopped/on-hold
  reason, condition.text               -> .reasonCode.text

Not modeled (future work): full profile conformance, terminology binding validation,
CarePlan aggregation. This demonstrates the alignment is executable, not that the dataset
is a certified FHIR bundle."""
from __future__ import annotations

_SR_TYPES = {"laboratory", "imaging", "procedure", "monitoring", "therapy_intervention",
             "appointment_followup", "referral_consultation"}
_INTENT = {"proposal", "plan", "order", "option"}


def _codeable(target) -> dict | None:
    if isinstance(target, str):
        target = {"text": target}
    if not isinstance(target, dict):
        return None
    cc = {}
    code = target.get("code")
    if isinstance(code, dict) and code.get("code"):
        sysmap = {"http://loinc.org": "http://loinc.org", "loinc": "http://loinc.org",
                  "http://snomed.info/sct": "http://snomed.info/sct", "RxNorm": "http://www.nlm.nih.gov/research/umls/rxnorm"}
        system = sysmap.get(code.get("system"), code.get("system"))
        cc["coding"] = [{"system": system, "code": str(code["code"]),
                         "display": code.get("display") or target.get("category") or target.get("text")}]
    txt = target.get("category") or target.get("text")
    if txt:
        cc["text"] = txt
    return cc or None


def _occurrence(time) -> dict | None:
    if isinstance(time, dict) and time.get("day_range"):
        d = time["day_range"][1]
        return {"occurrenceTiming": {"repeat": {"boundsDuration": {
            "value": float(d), "unit": "d", "system": "http://unitsofmeasure.org", "code": "d"}}}}
    return None


def to_fhir(intent: dict, subject: str = "Patient/example") -> dict | None:
    """Map one CIR intent to a FHIR R4 resource dict, or None for non-actionable 'other'."""
    typ = intent.get("type")
    ri = intent.get("request_intent") if intent.get("request_intent") in _INTENT else "plan"
    action, mod = intent.get("action"), intent.get("modality")
    status = "stopped" if action == "stop" else ("on-hold" if action == "hold" else "active")
    code = _codeable(intent.get("target"))
    subj = {"reference": subject}
    reason = [{"text": intent[k]} for k in ("reason",) if intent.get(k)]
    cond = intent.get("condition")
    if isinstance(cond, dict) and cond.get("text"):
        reason.append({"text": cond["text"]})

    if typ == "medication":
        r = {"resourceType": "MedicationRequest", "status": status, "intent": ri, "subject": subj,
             "medicationCodeableConcept": code or {"text": "medication"}}
        dose = {}
        if intent.get("frequency"):
            dose["timing"] = {"code": {"text": str(intent["frequency"])}}
        if mod == "optional" or (isinstance(cond, dict) and cond.get("text")):
            dose["asNeededBoolean"] = True
        if dose:
            r["dosageInstruction"] = [dose]
    elif typ in _SR_TYPES:
        r = {"resourceType": "ServiceRequest", "status": status, "intent": ri, "subject": subj,
             "code": code or {"text": (intent.get("target") or {}).get("text", "service") if isinstance(intent.get("target"), dict) else "service"}}
        if typ == "referral_consultation":
            r["category"] = [{"text": "referral"}]
        elif typ == "appointment_followup":
            r["category"] = [{"text": "follow-up"}]
    elif typ == "patient_instruction":
        r = {"resourceType": "CommunicationRequest", "status": status, "subject": subj,
             "payload": [{"contentString": (intent.get("target") or {}).get("text", "instruction")
                          if isinstance(intent.get("target"), dict) else str(intent.get("target") or "instruction")}]}
        return r
    else:
        return None

    occ = _occurrence(intent.get("time"))
    if occ:
        r.update(occ)
    if mod == "prohibited":
        r["doNotPerform"] = True
    if reason:
        r["reasonCode"] = reason
    return r


def validate(resource: dict) -> tuple[bool, str]:
    """Validate against FHIR R4B via fhir.resources (pydantic). Returns (ok, error)."""
    try:
        rt = resource.get("resourceType")
        mod = __import__(f"fhir.resources.R4B.{rt.lower()}", fromlist=[rt])
        getattr(mod, rt).parse_obj(resource)
        return True, ""
    except Exception as e:
        return False, f"{type(e).__name__}: {str(e)[:120]}"
