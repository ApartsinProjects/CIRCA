"""Central configuration. Local-first; no PHI leaves the machine."""
from __future__ import annotations
import os
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent          # labeling_app/
DATA_DIR = APP_ROOT / "var"                                # runtime state (git-ignored)
LOG_DIR = DATA_DIR / "logs"
DB_PATH = DATA_DIR / "labeling.db"

# Compliance switch (spec §12): keep annotation local unless explicitly allowed.
ALLOW_REMOTE_MODELS = os.environ.get("ALLOW_REMOTE_MODELS", "false").lower() == "true"

# Where the real credentialed corpora live (only read in debug/seed-real mode).
EXTERNAL = Path(os.environ.get(
    "MEDFOLLOW_EXTERNAL",
    APP_ROOT.parent / "MedFollow" / "Data" / "external",
))

ONTOLOGY_VERSION = "CIR-0.4"
PROMPT_VERSION = "intent-extract-1"
CROSSWALK_VERSION = "crosswalk-0.1"

for d in (DATA_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)


def _load_secrets() -> dict:
    """Read var/secrets.env (git-ignored KEY=VALUE lines) so local credentials (e.g. the
    UMLS API key) never live in code or env-export scripts. Env vars take precedence."""
    out = {}
    p = DATA_DIR / "secrets.env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    return out

_SECRETS = _load_secrets()


def secret(name: str, default: str | None = None):
    return os.environ.get(name) or _SECRETS.get(name) or default


# Terminology-coding backend (UMLS is strictly opt-in so the default path stays fast):
#   "fhir"      (default) tx.fhir.org + RxNav only, no key, no UMLS calls
#   "umls"      UMLS UTS primary, FHIR fallback (needs UMLS_API_KEY)
#   "fhir+umls" FHIR primary, UMLS fallback for concepts FHIR can't code
CODER_BACKEND = os.environ.get("CODER_BACKEND", "fhir").lower()
UMLS_API_KEY = secret("UMLS_API_KEY")
