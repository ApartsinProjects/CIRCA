"""Non-destructive source→CIR crosswalk (spec §2b). Produces CANDIDATE mappings
with confidence; never overwrites the source annotation."""
from __future__ import annotations
import re
from . import config

# source -> (matcher substring, {field: value}, confidence)
RULES = {
    "CLIP": [
        ("appointment", {"type": "appointment_followup", "action": "follow_up"}, 0.92),
        ("lab", {"type": "laboratory", "action": "obtain"}, 0.90),
        ("imaging", {"type": "imaging", "action": "obtain"}, 0.90),
        ("procedure", {"type": "procedure", "action": "perform"}, 0.88),
        ("medication", {"type": "medication", "action": "adjust"}, 0.85),
        ("instruction", {"type": "patient_instruction", "action": "instruct"}, 0.80),
        ("other", {"type": "other", "action": "other"}, 0.60),
    ],
    "MedDec": [   # DICTUM decision categories; labels read 'Category N: <name>'
        ("imaging", {"type": "imaging", "action": "obtain"}, 0.80),
        ("procedure", {"type": "procedure", "action": "perform"}, 0.82),
        ("drug", {"type": "medication", "action": "adjust"}, 0.80),          # 'Drug related'
        ("medication", {"type": "medication", "action": "adjust"}, 0.80),
        ("contact", {"type": "appointment_followup", "action": "follow_up"}, 0.70),  # 'Contact related'
        ("follow", {"type": "appointment_followup", "action": "follow_up"}, 0.78),
        ("defining problem", {"type": "other", "action": "other"}, 0.50),
    ],
    "PaniniQA": [   # labels read 'Aftercare instructions - ...' / 'Treatments - ...'; order matters
        ("medicine", {"type": "medication", "action": "adjust"}, 0.85),
        ("medication", {"type": "medication", "action": "adjust"}, 0.85),
        ("procedure", {"type": "procedure", "action": "perform"}, 0.82),
        ("test", {"type": "laboratory", "action": "obtain"}, 0.80),
        ("schedule", {"type": "appointment_followup", "action": "follow_up"}, 0.85),
        ("appointment", {"type": "appointment_followup", "action": "follow_up"}, 0.85),
        ("diet", {"type": "patient_instruction", "action": "instruct"}, 0.75),
        ("emergency", {"type": "patient_instruction", "action": "instruct"}, 0.75),
        ("instruction", {"type": "patient_instruction", "action": "instruct"}, 0.70),
    ],
    "simord": [   # order_type values
        ("lab", {"type": "laboratory", "action": "obtain"}, 0.90),
        ("medication", {"type": "medication", "action": "adjust"}, 0.88),
        ("imaging", {"type": "imaging", "action": "obtain"}, 0.88),
        ("referral", {"type": "referral_consultation", "action": "refer"}, 0.85),
        ("followup", {"type": "appointment_followup", "action": "follow_up"}, 0.85),
        ("follow-up", {"type": "appointment_followup", "action": "follow_up"}, 0.85),
    ],
    "ap_parsing": [   # action_item_type values (uppercased in source -> lowered here)
        ("medications", {"type": "medication", "action": "adjust"}, 0.85),
        ("observations_labs", {"type": "laboratory", "action": "obtain"}, 0.85),
        ("imaging", {"type": "imaging", "action": "obtain"}, 0.85),
        ("consults", {"type": "referral_consultation", "action": "refer"}, 0.85),
        ("therapeutic_procedures", {"type": "procedure", "action": "perform"}, 0.80),
        ("other_diagnostic_procedures", {"type": "procedure", "action": "obtain"}, 0.75),
        ("nutrition", {"type": "patient_instruction", "action": "instruct"}, 0.70),
        ("other", {"type": "other", "action": "other"}, 0.50),
    ],
    "synthetic": [   # for tests/fixtures
        ("appointment", {"type": "appointment_followup", "action": "follow_up"}, 0.92),
        ("lab", {"type": "laboratory", "action": "obtain"}, 0.90),
        ("imaging", {"type": "imaging", "action": "obtain"}, 0.90),
        ("referral", {"type": "referral_consultation", "action": "refer"}, 0.85),
    ],
}


def candidate_mapping(source: str, original_label: str) -> dict:
    """Return {mapping:{field:value}, confidence, matched_rule} — a proposal, not truth."""
    label = (original_label or "").lower()
    for needle, mapping, conf in RULES.get(source, []):
        # word-boundary match (+ optional plural) so 'lab' does NOT match 'label'
        if re.search(rf"\b{re.escape(needle)}s?\b", label):
            return {"mapping": dict(mapping), "confidence": conf,
                    "matched_rule": needle, "crosswalk_version": config.CROSSWALK_VERSION}
    return {"mapping": {"type": "other", "action": "other"}, "confidence": 0.3,
            "matched_rule": None, "crosswalk_version": config.CROSSWALK_VERSION}
