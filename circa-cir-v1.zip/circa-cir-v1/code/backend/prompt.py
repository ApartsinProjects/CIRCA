"""Prompt construction + response parsing — shared by the Bedrock annotator and
the offline prompt-tuning harness. Input encoding of existing annotations, the
system prompt, the output-format contract, and robust JSON parsing all live here
so they can be debugged without calling a live model."""
from __future__ import annotations
import json
import re
from . import schema

SYSTEM = (
    "You are a clinical NLP annotator extracting prospective clinical intentions "
    "into a strict schema. Existing annotations are EVIDENCE ONLY — not assumed "
    "correct or complete. Add intentions they miss; explicitly disagree when "
    "warranted. Use null when a field is absent.\n"
    "HARD RULES:\n"
    "- Return ONLY one JSON object, no prose, no markdown, no trailing commas.\n"
    "- 'type' MUST be one of the allowed types; 'request_intent' and 'modality' MUST "
    "be from their allowed lists — never invent values (e.g. never use 'instruct').\n"
    "- Every provenance 'span' MUST be copied VERBATIM (character-for-character) from "
    "the TEXT, not paraphrased.\n"
    "- Keep the output compact; prefer fewer, well-grounded intents over many."
)

SCHEMA_HINT = {
    "intents": [{
        "intent_id": "I1", "action": "repeat", "type": "imaging",
        "target": {"text": "chest CT", "category": "chest computed tomography"},
        "actor": None,
        "time": {"text": "in 3 months", "normalized": "P3M", "anchor": "document_date"},
        "frequency": None, "duration": None,
        "condition": {"text": "if the lesion persists", "kind": "applicability"},
        "reason": None, "goal": None, "request_intent": "plan",
        "modality": "recommended", "status": "planned",
        "provenance": [{"span": "Repeat chest CT in 3 months", "role": "action"}],
    }]
}


# SYSTEM_FULL is STATIC across all notes -> a cacheable prompt prefix (spec: budget).
# All the fixed content (rules, allowed vocab, schema, task) lives here so Bedrock
# prompt caching can reuse it; only the per-note packet below is dynamic.
_RUBRIC = (
    "FIELD RUBRIC (apply consistently):\n"
    "- action: use ONLY these verbs — obtain, repeat, refer, follow_up, monitor, adjust, "
    "start, stop, continue, perform, instruct, schedule, other. Map synonyms (order/draw/"
    "check→obtain; recheck→repeat; increase/titrate→adjust; discontinue→stop; assess→monitor; "
    "infuse/administer→perform; avoid/restrict/limit→instruct).\n"
    "- MEDICATION verb: a discharge-med line with a dose defaults to `continue` (the patient "
    "keeps taking it) UNLESS the note marks it NEW ('start','new','begin','initiate'→start), a "
    "DOSE CHANGE ('increase','decrease','titrate','changed'→adjust), or HELD/STOPPED "
    "('hold','stop','discontinue'→stop). A bare 'Drug 20 mg PO BID' line → continue.\n"
    "  * 'cont'/'cont.'/'continue'/'continuing' before a drug ALWAYS → action=continue, NEVER "
    "adjust. A bare drug name with no change verb (e.g. 'metoprolol', 'statin', 'sc heparin') "
    "→ continue. Use `adjust` ONLY when an explicit dose change is stated.\n"
    "- APPOINTMENT verb: a future visit/appointment is `follow_up` (reserve `schedule` only "
    "when the note's own verb is 'schedule'/'arrange' AND no follow-up sense is present).\n"
    "- request_intent (authority): proposal = a suggestion/consideration ('consider', 'may "
    "benefit from'); plan = an intended future action not yet ordered ('will follow up', "
    "'should have', 'plan to'); order = stated as an actionable order already placed "
    "('ordered', 'scheduled', 'arranged'); option = one of stated alternatives.\n"
    "- modality (strength, from the wording): considered ('consider','possible'); "
    "recommended ('recommend','should','please'); planned ('will','plan to'); ordered "
    "('ordered','arranged'); conditional (happens only if a condition holds); optional "
    "('if desired','as needed','prn'); prohibited ('do not','avoid').\n"
    "- target: an OBJECT with BOTH target.text (verbatim phrase copied from the note) AND "
    "target.category (the normalized clinical concept — e.g. 'complete blood count' not "
    "'CBC', 'chest CT' not 'CT'; expand abbreviations). For a referral/appointment, "
    "target.category is the SPECIALTY (e.g. 'cardiology'), NEVER a person's name.\n"
    "- reason, goal, actor, status, frequency, duration are PLAIN STRINGS (never objects). "
    "condition is an OBJECT {text, kind}. Only target is a {text, category} object.\n"
    "- PATIENT-DIRECTED guidance is a real intent, NOT 'other': 'take your meds as prescribed', "
    "'avoid alcohol', 'seek care / call us if you have fevers', 'weigh yourself daily', 'enter "
    "rehab' → type=patient_instruction (or medication/monitoring if a specific drug/vital is "
    "named), action=instruct (or continue/monitor). Reserve type=other and action=other for "
    "content with no clinical action.\n"
    "- TYPE tie-breaks: any administered DRUG is `medication` — even PRN, nebulized, or IV "
    "fluids/infusions. Reserve `therapy_intervention` for NON-drug procedures (physical "
    "therapy, dialysis, wound-care procedures). Use `patient_instruction` only when the note "
    "frames it as self-care guidance to the patient, not a clinician order.\n"
    "- time = WHEN the action happens (a follow-up date/offset: 'in 3 months', 'at next "
    "visit'). Copy the raw phrase VERBATIM into time.text (a script normalizes it — do NOT "
    "worry about ISO precision). Optionally add time.normalized (ISO-8601 P3M/P2W/P90D or an "
    "absolute date) for an absolute date the text can't express on its own.\n"
    "- frequency = HOW OFTEN a recurring action repeats (dosing/monitoring cadence: 'daily', "
    "'BID', 'Q12H', 'twice a day'). Put cadence in `frequency`, NEVER in time.\n"
    "- duration = HOW LONG it continues ('for 7 days', 'for 2 weeks'). Put it in `duration`, "
    "not time.\n"
    "- NEGATION: 'No X' / 'do not' / 'avoid' / 'stop' → modality=prohibited (NOT recommended).\n"
    "- ALWAYS capture 'if …', 'when …', 'as needed'/'prn', 'should … persist' clauses as a "
    "condition on the intent.\n"
    "- one intent per DISTINCT action; do NOT split a single action into several intents.\n"
)
SYSTEM_FULL = (
    SYSTEM
    + "\n\nALLOWED VALUES:\n"
    + f"  type ∈ {sorted(schema.ACTION_TYPES)}\n"
    + f"  request_intent ∈ {sorted(schema.REQUEST_INTENT)}\n"
    + f"  modality ∈ {sorted(schema.MODALITY)}\n\n"
    + _RUBRIC
    + "\nTASK: Extract ALL prospective clinical intentions from the TEXT. Existing "
    "annotations are EVIDENCE ONLY — add intentions they miss; disagree when warranted. "
    "Copy provenance spans verbatim from the TEXT.\n"
    "\nReturn ONLY one JSON object of this exact shape:\n" + json.dumps(SCHEMA_HINT)
)


def build_packet(doc: dict, anchors: list[dict]) -> str:
    """The DYNAMIC annotation packet (spec §2c): the note + raw source annotations +
    candidate mappings. Fixed instructions/schema live in SYSTEM_FULL (cached)."""
    lines = [f"DOCUMENT: type={doc.get('note_type', '')} date={doc.get('doc_date', '')}",
             "TEXT:", doc["text"], "", "EXISTING ANNOTATIONS (verbatim, per source):"]
    if not anchors:
        lines.append("  (none)")
    for a in anchors:
        lines.append(f"  {a['source']}: label={a['original_label']!r} span={a.get('span','')!r}")
    lines.append("CANDIDATE ONTOLOGY MAPPINGS (suggestions + confidence, NOT truth):")
    for a in anchors:
        c = a.get("candidate", {})
        lines.append(f"  {a['original_label']!r} -> {c.get('mapping')} ({c.get('confidence')})")
    lines += ["", "Extract now from the TEXT above. Return ONLY the JSON object."]
    return "\n".join(lines)


_FENCE = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.S)
_OBJ = re.compile(r"\{.*\}", re.S)


_TRAILING_COMMA = re.compile(r",(\s*[}\]])")


def extract_json(text: str) -> dict:
    """Robust: handle a bare object, a ```json fenced block, or prose+object;
    tolerate trailing commas (a common LLM JSON error)."""
    m = _FENCE.search(text) or _OBJ.search(text)
    if not m:
        raise ValueError("no JSON object found in model output")
    raw = m.group(1) if m.re is _FENCE else m.group(0)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return json.loads(_TRAILING_COMMA.sub(r"\1", raw))   # strip trailing commas, retry


def parse_response(text: str, source_text: str | None = None) -> tuple[list[dict], list[str]]:
    """Parse model text -> (valid_intents, problems). Never raises."""
    problems: list[str] = []
    try:
        data = extract_json(text)
    except Exception as e:
        return [], [f"parse: {e}"]
    intents = data.get("intents")
    if not isinstance(intents, list):
        return [], ["parse: missing 'intents' array"]
    valid = []
    for i, it in enumerate(intents):
        if not isinstance(it, dict):
            problems.append(f"intent[{i}]: not an object")
            continue
        it.setdefault("intent_id", f"I{i+1}")
        it = schema.coerce_intent(it)             # repair scalar-as-dict / condition-as-str
        intents[i] = it
        ok, errs = schema.validate_intent(it)
        if not ok:
            problems.append(f"intent[{i}] {it.get('intent_id')}: {'; '.join(errs)}")
            continue
        if source_text is not None:
            g = schema.check_grounded(it, source_text)
            if g:
                problems.append(f"intent[{i}] ungrounded: {'; '.join(g)}")
        valid.append(it)
    return valid, problems
