"""Canonicalize free-text field values before agreement comparison (spec §2c step 7:
'canonicalize before comparing'). Deterministic, lexical — expands common clinical
abbreviations, drops filler words, compares as token sets so 'chest CT', 'CT scan'
and 'CT of the chest' are treated as the same target rather than 3 disagreements.

A later layer can swap this for ontology coding (SNOMED/LOINC via tx.fhir.org)."""
from __future__ import annotations
import re
from . import temporal, medlist

# long form -> short canonical token (applied as a phrase substitution, lowercased)
ALIASES = {
    "computed tomography": "ct", "magnetic resonance imaging": "mri",
    "complete blood count": "cbc", "basic metabolic panel": "bmp",
    "comprehensive metabolic panel": "cmp", "electrocardiogram": "ecg",
    "electrocardiography": "ecg", "chest x-ray": "cxr", "chest xray": "cxr",
    "ultrasound": "us", "endoscopic retrograde cholangiopancreatography": "ercp",
    "endoscopic retrograde colangiopancreatography": "ercp",
    "follow up": "followup", "follow-up": "followup",
}
STOP = {"the", "a", "an", "of", "for", "to", "with", "and", "in", "on", "please",
        "scan", "study", "test", "imaging", "your", "his", "her", "patient", "repeat"}
# closed action vocabulary (spec): map synonyms -> a controlled verb set
ACTION_VOCAB = {"obtain", "repeat", "refer", "follow_up", "monitor", "adjust",
                "start", "stop", "continue", "perform", "instruct", "schedule", "other"}
ACTION_SYN = {
    "follow_up": "follow_up", "followup": "follow_up",
    "refer": "refer", "referral": "refer",
    "arrange": "schedule", "schedule": "schedule", "book": "schedule",
    "obtain": "obtain", "get": "obtain", "order": "obtain", "check": "obtain",
    "draw": "obtain", "send": "obtain", "measure": "obtain",
    "repeat": "repeat", "recheck": "repeat",
    "monitor": "monitor", "watch": "monitor", "observe": "monitor",
    "assess": "monitor", "evaluate": "monitor",
    "trend": "monitor", "weigh": "monitor", "manage": "monitor", "follow": "follow_up",
    "adjust": "adjust", "increase": "adjust", "decrease": "adjust",
    "titrate": "adjust", "change": "adjust", "dose": "adjust",
    "replete": "start", "supplement": "start", "use": "instruct",
    "start": "start", "begin": "start", "initiate": "start", "add": "start",
    "stop": "stop", "discontinue": "stop", "hold": "stop", "cease": "stop",
    "continue": "continue", "resume": "continue", "complete": "continue", "finish": "continue",
    "restart": "continue",   # restart a held med = resume
    "wean": "adjust", "taper": "adjust", "uptitrate": "adjust", "downtitrate": "adjust",
    "intubate": "perform", "administer": "perform",
    "seek": "instruct",   # 'seek medical attention' = a return-precaution instruction
    "perform": "perform", "do": "perform", "infuse": "perform", "administer": "perform",
    "instruct": "instruct", "advise": "instruct", "educate": "instruct", "counsel": "instruct",
    "avoid": "instruct", "restrict": "instruct", "limit": "instruct",   # 'no driving' = instruction (polarity handles the negation)
}


def _tokens(text: str) -> frozenset[str]:
    s = (text or "").lower()
    for long, short in ALIASES.items():
        s = s.replace(long, short)
    toks = re.findall(r"[a-z0-9]+", s)
    toks = [medlist._BRAND.get(t, t) for t in toks]     # brand -> generic (lasix -> furosemide)
    toks = [t[:-1] if len(t) > 3 and t.endswith("s") else t for t in toks]  # crude singular
    return frozenset(t for t in toks if t not in STOP)


def canon(field: str, value) -> object:
    """Return a comparable canonical form for a field value."""
    if value is None:
        return None
    if field == "time" and isinstance(value, dict):
        return value.get("normalized") or (value.get("text") or "").strip().lower()
    if field == "condition" and isinstance(value, dict):
        return frozenset(_tokens(value.get("text") or ""))
    if field == "action":
        v = str(value).strip().lower().replace("-", "_").replace(" ", "_")
        if v in ACTION_SYN:
            return ACTION_SYN[v]
        for t in re.findall(r"[a-z_]+", v):
            if t in ACTION_SYN:
                return ACTION_SYN[t]
        return (re.findall(r"[a-z_]+", v) or [v])[0]
    if field == "target":
        if isinstance(value, dict):               # dual repr {text, category, code}
            code = value.get("code")
            if isinstance(code, dict) and code.get("code"):
                return f"{code.get('system')}|{code.get('code')}"   # compare on standard code
            return _tokens(str(value.get("category") or value.get("text") or ""))
        return _tokens(str(value))
    if isinstance(value, str):
        return value.strip().lower()
    return value


# Coarse strength classes: the fine values (ordered/planned/recommended) are
# genuinely conflated in discharge language, so agreement is measured on the
# clinically meaningful strength — weak ('consider') vs active ('obtain') — while
# the fine value is still STORED. This is the distinction that actually matters.
MOD_CLASS = {"ordered": "active", "planned": "active", "recommended": "active",
             "considered": "weak", "optional": "weak",
             "conditional": "conditional", "prohibited": "prohibited"}
RI_CLASS = {"order": "committed", "plan": "committed", "directive": "committed",
            "proposal": "weak", "option": "weak"}


def _target_code(v):
    if isinstance(v, dict):
        c = v.get("code")
        if isinstance(c, dict) and c.get("code"):
            return f"{c.get('system')}|{c.get('code')}"
    return None


def _cat_tokens(v) -> frozenset:
    return _tokens(str(v.get("category") or v.get("text") or "")) if isinstance(v, dict) else _tokens(str(v))


def _txt_tokens(v) -> frozenset:
    return _tokens(str(v.get("text") or v.get("category") or "")) if isinstance(v, dict) else _tokens(str(v))


def _tok_match(ta, tb) -> bool:
    if not ta or not tb:
        return ta == tb
    if ta <= tb or tb <= ta:                      # one is a subset (specificity)
        return True
    return len(ta & tb) / len(ta | tb) >= 0.5     # or strong partial overlap (Jaccard)


def _target_agree(a, b) -> bool:
    """Agree if ANY representation matches — the model-generated abstraction is noisy
    and asymmetrically coded, so it must never OVERRIDE an exact verbatim match:
      (1) both carry the same standard code, OR
      (2) the verbatim phrases match (token subset / Jaccard>=0.5), OR
      (3) the normalized categories match.
    'pill endoscopy'/'capsule endoscopy' (same verbatim, divergent abstraction) agree
    on (2); 'CBC'/'complete blood count' (divergent verbatim, same abstraction) on (3)."""
    ca, cb = _target_code(a), _target_code(b)
    if ca and cb and ca == cb:
        return True
    return _tok_match(_txt_tokens(a), _txt_tokens(b)) or _tok_match(_cat_tokens(a), _cat_tokens(b))


def agree(field: str, a, b) -> bool:
    """Do two canonicalized values agree? Token-set fields match if one is a
    non-empty subset of the other (handles specificity like 'CT' vs 'chest CT');
    time is compared on day-ranges (P3M ≡ P90D ≡ '3 months'); modality/request_intent
    on coarse strength classes."""
    if field == "time":
        return temporal.agree(a, b)
    if field == "modality":
        return (MOD_CLASS.get(str(a).lower(), a) == MOD_CLASS.get(str(b).lower(), b)) if (a and b) else a == b
    if field == "request_intent":
        return (RI_CLASS.get(str(a).lower(), a) == RI_CLASS.get(str(b).lower(), b)) if (a and b) else a == b
    if field == "target":
        return _target_agree(a, b)
    ca, cb = canon(field, a), canon(field, b)
    if isinstance(ca, frozenset) and isinstance(cb, frozenset):
        if not ca or not cb:
            return ca == cb
        return ca <= cb or cb <= ca
    return ca == cb
