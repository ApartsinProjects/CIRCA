"""Deterministic temporal normalization + comparison (spec pipeline G). The LLM's
ISO strings are inconsistent (P3M vs P90D vs '3 months'), so we convert every time
value to a DAY RANGE and compare on days — making P3M ≡ P90D ≡ '3 months'."""
from __future__ import annotations
import re
from datetime import date

_ISO = re.compile(r"^P(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)W)?(?:(\d+)D)?$", re.I)
_DATE = re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})")


def _parse_date(s):
    m = _DATE.search(s or "")
    if not m:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None
_TEXT = re.compile(r"(\d+)(?:\s*[-–]+\s*|\s+to\s+)?(\d+)?\s*(day|week|month|year|wk|mo|yr)s?", re.I)
_UNIT = {"day": 1, "week": 7, "month": 30, "year": 365,
         "wk": 7, "mo": 30, "yr": 365}
# spelled-out numbers the LLM leaves in the verbatim phrase ('in a week', 'two weeks')
_WORDNUM = {"a": "1", "an": "1", "one": "1", "two": "2", "three": "3", "four": "4",
            "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10",
            "eleven": "11", "twelve": "12", "couple": "2", "few": "3", "several": "3"}
_NEXT = re.compile(r"\bnext\s+(day|week|month|year)\b", re.I)
# deictic day references -> offset days from the document date
_RELDAY = [(re.compile(r"\b(today|tonight|this (morning|afternoon|evening|admission)|now|"
                       r"immediately|at discharge|on discharge)\b", re.I), 0),
           (re.compile(r"\btomorrow\b", re.I), 1),
           (re.compile(r"\bin two days|day after tomorrow\b", re.I), 2)]


def _sub_wordnums(s: str) -> str:
    return re.sub(r"\b([a-z]+)\b",
                  lambda m: _WORDNUM.get(m.group(1).lower(), m.group(1)), s)


def iso_to_days(s: str):
    if not s:
        return None
    m = _ISO.match(s.strip())
    if not m or not any(m.groups()):
        return None
    y, mo, w, d = (int(x) if x else 0 for x in m.groups())
    return y * 365 + mo * 30 + w * 7 + d


def _iso_range(s: str):
    """Parse a slash/dash-separated ISO range ('P3W/P13W', 'P3W-P13W') -> (lo, hi)."""
    if not s:
        return None
    parts = re.split(r"\s*[/–]\s*|(?<=[A-Za-z])-(?=P)", s.strip())
    if len(parts) == 2:
        lo, hi = iso_to_days(parts[0]), iso_to_days(parts[1])
        if lo is not None and hi is not None:
            return (min(lo, hi), max(lo, hi))
    return None


def text_to_days(s: str):
    """Deterministic parse of a verbatim time phrase -> (lo_days, hi_days). Handles
    'in 3 months', 'two weeks', 'in a week', '2-3 weeks', 'next month'. This is the
    single normalizer: two models that quote the same phrase get the SAME days."""
    if not s:
        return None
    for rx, d in _RELDAY:                            # 'today'->0, 'tomorrow'->1
        if rx.search(s):
            return (d, d)
    s = re.sub(r"\bof\b", " ", _sub_wordnums(s))     # 'couple of weeks' -> '2  weeks'
    nx = _NEXT.search(s)
    if nx:
        u = _UNIT[nx.group(1).lower()]
        return (u, u)
    m = _TEXT.search(s)
    if not m:
        return None
    lo = int(m.group(1)); hi = int(m.group(2)) if m.group(2) else lo
    u = _UNIT[m.group(3).lower()]
    return (min(lo, hi) * u, max(lo, hi) * u)


def to_days(time):
    """Return (min_days, max_days) or None from ISO / value+unit / text / offsets."""
    if time is None:
        return None
    if isinstance(time, str):
        d = iso_to_days(time)
        if d is not None:
            return (d, d)
        return _iso_range(time) or text_to_days(time)
    if isinstance(time, dict):
        if time.get("day_range"):                    # pre-resolved offset from doc_date
            dr = time["day_range"]
            return (dr[0], dr[1])
        nz = time.get("normalized") or ""
        d = iso_to_days(nz)
        if d is not None:
            return (d, d)
        rng = _iso_range(nz)                          # 'P3W/P13W' style range
        if rng is not None:
            return rng
        if time.get("value") and time.get("unit"):
            u = _UNIT.get(str(time["unit"]).rstrip("s").lower())
            if u:
                v = int(time["value"]); return (v * u, v * u)
        if time.get("min_offset_days") is not None:
            return (time["min_offset_days"],
                    time.get("max_offset_days", time["min_offset_days"]))
        r = text_to_days(time.get("text") or "")
        if r:
            return r
    return None


def resolve(time, doc_date):
    """Anchor a time value to doc_date -> day_range offset. SCRIPT-NORMALIZED: our
    deterministic parse of the verbatim time.text WINS over the model's own ISO guess,
    so two models quoting the same phrase always agree (removes P3W-vs-P21D noise).
    Absolute dates ('2158-12-05') are anchored to the document date. Mutates a copy."""
    if not isinstance(time, dict):
        return time
    time = dict(time)
    dr = text_to_days(time.get("text") or "")        # (1) OUR parse of the verbatim phrase
    if dr is None:
        dr = to_days(time)                           # (2) fall back to ISO/offsets the model gave
    if dr is None:                                   # (3) absolute date anchored to doc_date
        dd = _parse_date(doc_date)
        for key in ("normalized", "text", "expression"):
            ad = _parse_date(time.get(key) or "")
            if ad and dd:
                off = (ad - dd).days
                dr = (off, off)
                break
    if dr is not None:
        time["day_range"] = list(dr)
    return time


def normalize(time):
    """Enrich a time dict with a canonical day range + ISO (for storage)."""
    if not isinstance(time, dict):
        return time
    dr = to_days(time)
    if dr is not None:
        time = dict(time)
        time["day_range"] = list(dr)
        if not time.get("normalized") and dr[0] == dr[1]:
            time["normalized"] = f"P{dr[0]}D"
    return time


_FREQ = re.compile(
    r"\b(daily|once daily|twice daily|bid|tid|qid|qhs|qd|q\d+h|q\.?d\.?|"
    r"every\s+\d+\s+hours?|(\d+|once|twice|thrice)\s+times?\s+(a|per)\s+day|"
    r"(once|twice|thrice)\s+(a|per)\s+day|prn|as needed|nightly|"
    r"weekly|monthly|every\s+morning|every\s+night)\b", re.I)
_WHEN = re.compile(r"\b(in|within|after|before|on)\b|\d{4}-\d", re.I)


def split_frequency(intent: dict) -> dict:
    """Move medication dosing FREQUENCY out of `time` (which is WHEN the action
    occurs) into `frequency`. 'daily'/'BID'/'Q12H' are recurrence, not follow-up timing."""
    t = intent.get("time")
    txt = (t.get("text") or t.get("normalized") or "") if isinstance(t, dict) else (t or "")
    if txt and _FREQ.search(str(txt)):
        intent = dict(intent)
        intent["frequency"] = intent.get("frequency") or str(txt)
        if not _WHEN.search(str(txt)):           # pure frequency -> not a follow-up time
            intent["time"] = None
    return intent


def agree(a, b, tol: float = 0.15) -> bool:
    da, db = to_days(a), to_days(b)
    if da is None or db is None:
        return da == db
    (a0, a1), (b0, b1) = da, db
    if a1 >= b0 and b1 >= a0:                    # ranges overlap
        return True
    ma, mb = (a0 + a1) / 2, (b0 + b1) / 2         # or midpoints within tolerance
    return abs(ma - mb) <= tol * max(ma, mb, 1)
