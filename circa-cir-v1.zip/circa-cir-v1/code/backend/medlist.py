"""Deterministic medication reconciliation — the note's OWN answer to start/adjust/
continue/stop, which the three models otherwise each guess at.

Discharge summaries carry a 'Medications on Admission' list and a 'Discharge Medications'
list. The admission list is usually terse brand names ('ASA, lipitor, plavix'); the
discharge list is detailed generic lines ('Atorvastatin 10 mg Tablet Sig: ... PO DAILY').
We normalize both to a generic ingredient (via a brand->generic lexicon) and compare:
    on both, same strength                    -> continue
    on both, changed strength                 -> adjust
    in discharge, admission list has NO match -> start  (only when admission parsed)
    on admission, not in discharge            -> stop

Applied as a uniform post-annotation arbiter (like temporal/polarity resolution): it is
the note's ground truth, not fabricated agreement. HONESTY RULE: when a drug is not
confidently matched we return NOTHING for it and leave the model's own verb untouched —
we never guess 'start' just because names failed to align."""
from __future__ import annotations
import re

_ADMIT_H = re.compile(r"medications?\s+on\s+admission\s*:?", re.I)
_DISCH_H = re.compile(r"discharge\s+medications?\s*:?", re.I)
_NEXT_H = re.compile(r"\n\s*(?:[A-Z][A-Za-z ]{2,40}:|discharge\s+(?:disposition|diagnosis|"
                     r"condition|instructions?)|followup\s+instructions?|facility:)", re.I)
_STRENGTH = re.compile(r"(\d+\.?\d*)\s*(mg|mcg|g|unit|units|ml|%|puff|meq|gram)", re.I)
# non-drug tokens that appear in wrapped detailed lines
_NOISE = {"tablet", "capsule", "sig", "one", "two", "three", "po", "tab", "cap", "oral",
          "delayed", "release", "sustained", "extended", "sr", "er", "xl", "solution",
          "times", "day", "daily", "week", "am", "pm", "as", "needed", "by", "mouth",
          "inhalation", "subcutaneous", "injection", "packet", "powder", "patch", "nan"}
# common brand -> generic ingredient (discharge lists are generic; admission often brand)
_BRAND = {
    "asa": "aspirin", "ecasa": "aspirin", "lipitor": "atorvastatin", "zocor": "simvastatin",
    "plavix": "clopidogrel", "coumadin": "warfarin", "lasix": "furosemide",
    "norvasc": "amlodipine", "zestril": "lisinopril", "prinivil": "lisinopril",
    "zantac": "ranitidine", "zoloft": "sertraline", "prozac": "fluoxetine",
    "toprol": "metoprolol", "lopressor": "metoprolol", "tenormin": "atenolol",
    "glucophage": "metformin", "oscal": "calcium", "os-cal": "calcium",
    "colace": "docusate", "senokot": "senna", "protonix": "pantoprazole",
    "prilosec": "omeprazole", "nexium": "esomeprazole", "synthroid": "levothyroxine",
    "coreg": "carvedilol", "diovan": "valsartan", "cozaar": "losartan",
    "hctz": "hydrochlorothiazide", "motrin": "ibuprofen", "advil": "ibuprofen",
    "tylenol": "acetaminophen", "percocet": "oxycodone", "ativan": "lorazepam",
    "haldol": "haloperidol", "insulin": "insulin", "lantus": "insulin",
    "humalog": "insulin", "aspirin": "aspirin",
}


def _section(text: str, header: re.Pattern) -> str:
    m = header.search(text or "")
    if not m:
        return ""
    rest = text[m.end():]
    nxt = _NEXT_H.search(rest)
    return rest[:nxt.start()] if nxt else rest[:2500]


def _generic(name: str) -> str:
    """Map a raw drug token to a normalized generic ingredient (first word, de-branded)."""
    toks = [t for t in re.findall(r"[a-zA-Z]+", (name or "").lower()) if t not in _NOISE]
    if not toks:
        return ""
    head = toks[0]
    return _BRAND.get(head, head)


def _parse_detailed(section: str) -> dict:
    """Discharge-style numbered detailed lines -> {generic: {'strength': str|None}}."""
    meds = {}
    for item in re.split(r"\n\s*\d+\.", "\n" + section):       # split on '1.' '2.' ...
        item = item.strip()
        st = _STRENGTH.search(item)
        if not st:                                             # a real med line has a strength
            continue
        g = _generic(item.split(str(st.group(1)))[0])         # name is before the strength
        if len(g) >= 3:
            meds[g] = {"strength": st.group(0).lower().replace(" ", "")}
    return meds


def _parse_list(section: str) -> dict:
    """Admission-style terse list (comma/newline separated brand names) -> {generic: {}}."""
    meds = {}
    for tok in re.split(r"[,\n;]", section):
        g = _generic(tok)
        if len(g) >= 3:
            meds[g] = {"strength": (_STRENGTH.search(tok).group(0).lower().replace(" ", "")
                                    if _STRENGTH.search(tok) else None)}
    return meds


def reconcile(note_text: str) -> dict:
    """Return {generic_drug: action} from the note's admission/discharge lists. Only
    confident classifications are emitted (see module docstring)."""
    disch = _parse_detailed(_section(note_text, _DISCH_H))
    admit_sec = _section(note_text, _ADMIT_H)
    admit = _parse_list(admit_sec)
    if len(admit) < 2:                                        # fall back to detailed admission
        admit = _parse_detailed(admit_sec) or admit
    out = {}
    admit_parsed = len(admit) >= 2
    for name, d in disch.items():
        a = admit.get(name)
        if a is not None:
            if a.get("strength") and d.get("strength") and a["strength"] != d["strength"]:
                out[name] = "adjust"
            else:
                out[name] = "continue"
        elif admit_parsed:                                   # confidently absent from a parsed list
            out[name] = "start"
        # else: admission list unusable -> emit nothing, leave the model's verb
    for name in admit:
        if name not in disch and admit_parsed:
            out[name] = "stop"
    return out


# ingredient -> drug class, so a model that names the CLASS ('diuretic') can bridge to the
# specific INGREDIENT present in this note's med list (Fable B1). Common discharge classes.
INGREDIENT_CLASS = {
    "furosemide": "diuretic", "hydrochlorothiazide": "diuretic", "bumetanide": "diuretic",
    "torsemide": "diuretic", "spironolactone": "diuretic", "metolazone": "diuretic",
    "metoprolol": "beta blocker", "atenolol": "beta blocker", "carvedilol": "beta blocker",
    "propranolol": "beta blocker", "bisoprolol": "beta blocker", "labetalol": "beta blocker",
    "haloperidol": "antipsychotic", "quetiapine": "antipsychotic", "olanzapine": "antipsychotic",
    "risperidone": "antipsychotic", "ziprasidone": "antipsychotic",
    "atorvastatin": "statin", "simvastatin": "statin", "pravastatin": "statin",
    "rosuvastatin": "statin", "lovastatin": "statin",
    "warfarin": "anticoagulant", "heparin": "anticoagulant", "enoxaparin": "anticoagulant",
    "apixaban": "anticoagulant", "rivaroxaban": "anticoagulant", "dabigatran": "anticoagulant",
    "lisinopril": "ace inhibitor", "enalapril": "ace inhibitor", "ramipril": "ace inhibitor",
    "captopril": "ace inhibitor", "amlodipine": "calcium channel blocker",
    "diltiazem": "calcium channel blocker", "verapamil": "calcium channel blocker",
    "aspirin": "antiplatelet", "clopidogrel": "antiplatelet",
    "omeprazole": "proton pump inhibitor", "pantoprazole": "proton pump inhibitor",
    "metformin": "oral hypoglycemic", "glyburide": "oral hypoglycemic", "glipizide": "oral hypoglycemic",
}
# class-name aliases models use -> canonical class in INGREDIENT_CLASS values
CLASS_ALIAS = {"betablocker": "beta blocker", "beta-blocker": "beta blocker",
               "ppi": "proton pump inhibitor", "ace-inhibitor": "ace inhibitor",
               "acei": "ace inhibitor", "ccb": "calcium channel blocker",
               "anticoagulation": "anticoagulant", "blood thinner": "anticoagulant",
               "diuretics": "diuretic", "statins": "statin", "antipsychotics": "antipsychotic"}
_CLASSES = set(INGREDIENT_CLASS.values())


def _bridge_class(target_text: str, recon: dict) -> str | None:
    """If the target names a drug CLASS, return the note's single ingredient of that class
    (its action), else None. Scans the RAW target text for a class term (multi-word classes
    like 'beta blocker' included). Bridges ONLY when EXACTLY ONE ingredient of the class is
    present — ambiguity (two drugs of the same class) yields no bridge (no false agreement)."""
    t = (target_text or "").lower()
    cls = next((c for term, c in CLASS_ALIAS.items() if term in t),
               next((c for c in _CLASSES if c in t), None))
    if not cls:
        return None
    matches = [drug for drug in recon if INGREDIENT_CLASS.get(drug.split()[0]) == cls]
    return recon[matches[0]] if len(matches) == 1 else None


def _target_name(target) -> str:
    if isinstance(target, dict):
        target = target.get("category") or target.get("text") or ""
    return _generic(re.split(r"[\d(]", str(target), maxsplit=1)[0])


def recon_verb(intent: dict, recon: dict):
    """The reconciliation verb this intent's target resolves to, or None if unmatched.
    (Does not mutate; used for cluster-level arbitration.)"""
    r = resolve_action(intent, recon)
    return r["action"] if r.get("_action_source") == "medlist_reconciliation" else None


def cluster_arbiter(members: list[dict], recon: dict):
    """All-or-nothing cluster arbiter: return a verb ONLY when EVERY member's target
    resolves to the SAME reconciliation verb. Otherwise None -> leave the models' verbs
    untouched. This can only CONVERGE a cluster, never break a pre-existing agreement
    (the partial-override failure mode measured on the per-intent arbiter)."""
    if not recon or not members:
        return None
    verbs = [recon_verb(it, recon) for it in members]
    if all(v is not None for v in verbs) and len(set(verbs)) == 1:
        return verbs[0]
    return None


def resolve_action(intent: dict, recon: dict) -> dict:
    """If a medication intent's target matches a reconciled drug, set its action to the
    note-derived verb (deterministic). Records the override source. No-op otherwise."""
    if not recon or intent.get("type") != "medication":
        return intent
    name = _target_name(intent.get("target"))
    verb = recon.get(name)
    if verb is None and name:                                # first-word fallback (e.g. 'insulin')
        first = name.split()[0]
        for k, v in recon.items():
            if k.split()[0] == first:
                verb = v; break
    if verb is None:                                         # class -> single ingredient (B1)
        tgt = intent.get("target")
        raw = (tgt.get("category") or tgt.get("text") or "") if isinstance(tgt, dict) else str(tgt or "")
        verb = _bridge_class(raw, recon)
    if verb:
        intent = dict(intent)
        intent["action"] = verb
        intent["_action_source"] = "medlist_reconciliation"
    return intent
