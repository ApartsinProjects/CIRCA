"""Formal gold evaluation of harmonization quality: for each dataset, does our CIR
output COVER the dataset's own gold annotations, and is the harmonized TYPE correct?

Metrics (computed FREE from preserved responses + the datasets' gold anchors):
  anchor_recall  - fraction of gold source annotations covered by >=1 system intent
                   whose provenance span overlaps the gold span (token Jaccard >= 0.3
                   or substring). This is the harmonization faithfulness metric.
  type_accuracy  - among COVERED anchors, fraction where the system intent's type equals
                   the type the crosswalk expects for that gold label.

We deliberately DO NOT report precision: each dataset annotates only a partial slice of
the intents in a note (CLIP=follow-ups, MedDec=decisions, ...), so intents our system adds
beyond the gold are the POINT of harmonization, not false positives. Reporting precision
against a partial gold would be an invalid, construct-mismatched number.

System output per note = the UNION of the 3 models' intents (max coverage), with the
per-cluster majority type used for type accuracy.

Run:  python tools/gold_eval.py
"""
from __future__ import annotations
import sys, json, re, pathlib
from collections import Counter, defaultdict
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from backend import config, prompt, crosswalk   # noqa: E402


_NUMWORD = {"one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6",
            "seven": "7", "eight": "8", "nine": "9", "ten": "10", "eleven": "11",
            "twelve": "12", "fifteen": "15", "twenty": "20", "thirty": "30",
            "milligram": "mg", "milligrams": "mg", "once": "", "daily": "day"}


def _toks(s):
    s = (s or "").lower()
    s = re.sub(r"[a-z]+", lambda m: _NUMWORD.get(m.group(0), m.group(0)), s)  # 'fifteen'->'15'
    return {t for t in re.findall(r"[a-z0-9]+", s) if len(t) > 2}


def _target_text(intent_target):
    if isinstance(intent_target, dict):
        return f"{intent_target.get('category','')} {intent_target.get('text','')}"
    return str(intent_target or "")


def _overlap(gold_span, prov_spans):
    """Asymmetric containment: a gold span and a provenance span match when most of the
    SHORTER span's content tokens appear in the other (handles short-phrase-in-long-
    sentence, which symmetric Jaccard misses). Threshold 0.6 of the smaller side."""
    g = _toks(gold_span)
    if not g:
        return False
    for p in prov_spans:
        pt = _toks(p)
        if not pt:
            continue
        inter = len(g & pt)
        if inter and inter / min(len(g), len(pt)) >= 0.6:
            return True
    return False


def _system_intents(note_outs):
    """Flatten all models' intents for a note into (type, provenance_spans) records."""
    recs = []
    for st, ints in note_outs.items():
        for it in ints:
            spans = [p.get("span", "") for p in (it.get("provenance") or [])]
            spans.append(_target_text(it.get("target")))     # note-grounded concept, for match
            recs.append({"type": it.get("type"), "action": it.get("action"), "spans": spans})
    return recs


def _load_gold():
    """dataset -> {doc_id: [(label, span)]}. Reuses the dataset loaders' anchors as gold."""
    import prompt_tune_real as ptr
    import prompt_tune_datasets as ptd
    gold = {}
    # CLIP
    clip = ptr.load_clip_anchors(8)
    gold["CLIP"] = {d: [(lab, sent) for lab, sent in a] for d, a in clip.items()}
    # the four generalization datasets (anchors already carry (label, span))
    for ds in ("meddec", "ap_parsing", "paniniqa", "simord"):
        docs = ptd.LOADERS[ds](8)
        gold[ds] = {rec["doc_id"]: [(a["original_label"], a["span"]) for a in rec["anchors"]]
                    for rec in docs}
    return gold


def main():
    runs = config.DATA_DIR / "llm_runs.jsonl"
    latest = {}
    for line in open(runs, encoding="utf-8"):
        r = json.loads(line)
        if r.get("kind") == "verify" or not r.get("doc"):
            continue
        latest[(r["doc"], r["strategy"])] = r["response"]
    by_ds = defaultdict(lambda: defaultdict(dict))
    for (doc, st), resp in latest.items():
        ds = str(doc).split(":")[0]
        did = str(doc).split(":", 1)[1] if ":" in str(doc) else str(doc)
        ints, _ = prompt.parse_response(resp)
        by_ds[ds][did][st] = ints

    gold = _load_gold()
    src_of = {"CLIP": "CLIP", "meddec": "MedDec", "ap_parsing": "ap_parsing",
              "paniniqa": "PaniniQA", "simord": "simord"}
    artifact = {}                      # persisted adapted-label report (per dataset -> anchors)
    print(f"{'dataset':12} {'anchors':>8} {'recall':>8} {'rel_recall':>11} {'type_acc':>9}")
    print("-" * 55)
    for ds in ("CLIP", "meddec", "ap_parsing", "paniniqa", "simord"):
        docs = by_ds.get(ds) or {}
        cov = [0, 0]; rel = [0, 0]; typ = [0, 0]; rows = []
        for did, glist in gold.get(ds, {}).items():
            outs = docs.get(did) or docs.get(f"{did}")
            if not outs:
                continue
            sysrecs = _system_intents(outs)
            for label, span in glist:
                expected = crosswalk.candidate_mapping(src_of[ds], label).get("mapping", {}).get("type")
                relevant = expected not in (None, "other")     # a prospective gold label
                hits = [r for r in sysrecs if _overlap(span, r["spans"])]
                covered = bool(hits)
                majtype = Counter(r["type"] for r in hits).most_common(1)[0][0] if hits else None
                cov[1] += 1; cov[0] += covered
                if relevant:
                    rel[1] += 1; rel[0] += covered
                if covered and expected:
                    typ[1] += 1; typ[0] += (majtype == expected)
                rows.append({"doc": did, "gold_label": label, "adapted_type": expected,
                             "relevant": relevant, "span": span[:120],
                             "covered": covered, "system_type": majtype})
        artifact[ds] = {"anchors": cov[1], "recall": cov[0], "relevant": rel[1],
                        "relevant_covered": rel[0], "type_ok": typ[0], "type_total": typ[1],
                        "rows": rows}
        if cov[1]:
            rr = f"{100*rel[0]/rel[1]:9.0f}%" if rel[1] else "        na"
            ta = f"{100*typ[0]/typ[1]:7.0f}%" if typ[1] else "     na"
            print(f"{ds:12} {cov[1]:8d} {100*cov[0]/cov[1]:7.0f}% {rr} {ta}")
    out = config.DATA_DIR / "gold_eval.json"                   # SAVE adapted labels + coverage
    out.write_text(json.dumps(artifact, indent=1), encoding="utf-8")
    print(f"\nadapted-label report saved -> {out} (per-anchor gold_label -> adapted_type, "
          "relevant flag, covered flag, system_type)")
    print("\nrel_recall = recall over RELEVANT (prospective) gold labels only "
          "(excludes retrospective/other, e.g. MedDec 'Defining problem').\n"
          "note: recall = gold anchors covered by a grounded system intent; "
          "type_acc = crosswalk-expected type matched on covered anchors.\n"
          "precision is intentionally omitted (partial gold; added intents are the goal).\n"
          "GOLD GRANULARITY (verified by inspection): ap_parsing (ACTION_ITEM) and simord\n"
          "(orders) are DISCRETE-ACTION gold -> anchor recall is directly meaningful.\n"
          "CLIP/MedDec/PaniniQA gold is SENTENCE/SPAN-level and over-segments (appointment\n"
          "logistics: address/phone/'Facility:'; MedDec 'Defining problem' diagnoses) into\n"
          "spans we correctly do NOT emit as separate intents, so their anchor recall is a\n"
          "LOWER BOUND, not a miss rate. ap_parsing is the clean intent-level benchmark.")


if __name__ == "__main__":
    main()
