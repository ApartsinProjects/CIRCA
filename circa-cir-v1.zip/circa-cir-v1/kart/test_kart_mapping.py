"""Correctness tests for the offset remap — the safety net for char-span labels."""
import kart_mapping as km


def const_surrogate(note_id, inner):
    # deliberately a DIFFERENT length than the [**...**] tag, to force offset shift
    return "Dr. Smith" if "name" in inner.lower() else "GEN"


def test_no_placeholder_survives():
    raw = "See Dr. [**Last Name (STitle) **] today."
    filled, _, _ = km.fill_with_map(raw, "n1", surrogate=const_surrogate)
    assert "[**" not in filled and "**]" not in filled


def test_span_projection_preserves_content():
    # annotation on a clinical span that sits AFTER a replaced tag
    raw = "See Dr. [**Last Name (STitle) **] today. Repeat CBC in 1 week."
    s = raw.index("Repeat CBC"); e = s + len("Repeat CBC")
    filled, remap, _ = km.fill_with_map(raw, "n1", surrogate=const_surrogate)
    ps, pe = remap.project_span(s, e)
    assert filled[ps:pe] == "Repeat CBC", (filled[ps:pe],)


def test_reproducible_and_consistent():
    raw = "A [**Hospital1 69**] B [**Hospital1 69**] C"
    f1, _, m1 = km.fill_with_map(raw, "n2", surrogate=const_surrogate)
    f2, _, m2 = km.fill_with_map(raw, "n2", surrogate=const_surrogate)
    assert f1 == f2 and m1 == m2                      # reproducible
    assert len(set(m1.values())) == 1                 # same tag -> same surrogate (I1)


def test_record_roundtrip_projects_correctly():
    raw = "X [**Name 1**] Y [**Name 2**] Z target here"
    filled, remap, pmap = km.fill_with_map(raw, "n3", surrogate=const_surrogate)
    s = raw.index("target here"); e = s + len("target here")
    rec = km.mapping_record("n3", raw, pmap)
    r2 = km.remap_from_record(rec)
    assert filled[r2.project(s):r2.project(e)] == "target here"


def test_position_inside_replacement_clamps():
    raw = "[**Hospital1 69**]tail"
    filled, remap, _ = km.fill_with_map(raw, "n4", surrogate=const_surrogate)
    assert remap.project(5) == 0                       # inside the tag -> surrogate start


def test_multiple_spans_all_project():
    raw = ("[**Date 1**] Problem: [**Last Name **] noted. "
           "Plan: repeat BMP. Follow up with cardiology.")
    filled, remap, _ = km.fill_with_map(raw, "n5", surrogate=const_surrogate)
    for phrase in ("repeat BMP", "Follow up with cardiology"):
        s = raw.index(phrase); e = s + len(phrase)
        ps, pe = remap.project_span(s, e)
        assert filled[ps:pe] == phrase
