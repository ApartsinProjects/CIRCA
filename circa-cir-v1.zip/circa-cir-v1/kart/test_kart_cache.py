"""kart_cache: one fill per MIMIC record, identical for every dataset that references it."""
import kart_cache


def test_same_record_identical_fill_across_datasets(tmp_path):
    raw = "Pt [**Last Name (STitle) 1537**] f/u [**Hospital 12**] on [**2158-12-05**]."
    # two different dataset callers, same MIMIC row id -> byte-identical filled text
    a = kart_cache.filled_note("999", raw, tmp_path)          # e.g. CLIP caller
    b = kart_cache.filled_note("999", raw, tmp_path)          # e.g. MedDec caller (cache hit)
    assert a == b
    assert "[**" not in a                                     # de-id tags replaced
    assert (tmp_path / "999.json").exists()                   # materialized once
    assert kart_cache.mapping_for("999", tmp_path)            # offset map stored for span projection
    assert kart_cache.canonical_key("999") == "MIMIC:999"     # dataset-independent key


def test_cache_is_read_back_not_refilled(tmp_path):
    raw = "Repeat CBC in [**Location 5**]."
    first = kart_cache.filled_note("42", raw, tmp_path)
    # a later caller passing different raw text still gets the CACHED fill for that row id
    second = kart_cache.filled_note("42", "totally different text", tmp_path)
    assert first == second
