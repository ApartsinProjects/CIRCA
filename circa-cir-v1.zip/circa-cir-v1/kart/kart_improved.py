#!/usr/bin/env python
"""Hardened KART-style surrogate filler + issue scan on real MIMIC discharge summaries.

Design goals (LOCAL ONLY -- never transmit note text anywhere):
  - taxonomy tracks the PhysioNet `deid` tag grammar (see explore_grammar.py output),
    so classification is principled rather than case-by-case.
  - two flavours of DATE token are separated:
        * numeric date VALUE  ([**2118-6-2**], [**5-9**]) -> interval-preserving
          backshift of the year by a per-note constant; month/day preserved verbatim.
        * date LABEL           ([**Month/Day/Year 3143**], [**Year (4 digits)**],
          [**Date Range**], [**Holiday**]) -> a plausible SURROGATE date is emitted
          (never the raw label), consistent per placeholder.
  - numeric-ID labels ([**Job Number 4520**], [**Numeric Identifier 12**], ...) route
    to numeric IDs, never to job titles or names.
  - names split into first / last / full / initials; contact labels (CC Contact Info,
    Dictator Info, Pager) are covered.
  - anything unmatched is FLAGGED (UNCLASSIFIED), never silently namified in the report.

Invariants asserted every run (see sanity_check):
  I1  consistency        same placeholder string -> exactly one surrogate string.
  I2  interval-preserved  every numeric full date has year shifted by the SAME delta
                          and identical month/day.

Sampling depends on the round index (env KART_ROUND, 0..3): round r inspects the 10
notes whose ROW_ID % 4 == r (built once by build_pool.py -> pool.json), so each round
looks at DIFFERENT notes.
"""
import json, os, re, hashlib, random, sys
from collections import Counter
from faker import Faker

OUT = os.path.dirname(os.path.abspath(__file__))
PH = re.compile(r"\[\*\*(.*?)\*\*\]")
ROUND = os.environ.get("KART_ROUND", "0")               # key into the pool file
POOLFILE = os.environ.get("KART_POOLFILE", "pool.json") # pool.json (rounds) | pool_cycles.json
# Collision handling for name tokens with NO group id (e.g. "[**Doctor Last Name **]"):
#   "string"     -> invariant I1 = same placeholder STRING maps to one surrogate (default).
#   "occurrence" -> invariant I1 = same (STRING, OCCURRENCE index) maps to one surrogate;
#                   each distinct mention of an id-less name gets its own surrogate, which
#                   separates distinct clinicians that the de-id tool failed to group.
COLLISION_MODE = os.environ.get("KART_COLLISION", "string")
assert COLLISION_MODE in ("string", "occurrence")

# ---- 1. load the round's notes (only when run as a script; safe to import) ----
try:
    pool = json.load(open(os.path.join(OUT, POOLFILE), encoding="utf-8"))
    notes = pool[str(ROUND)]
except (FileNotFoundError, KeyError, ValueError):
    pool, notes = {}, {}

# ---- 2. numeric date-value patterns (real digits) -----------------------
D_YMD = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$")
D_MDY = re.compile(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$")
D_YM  = re.compile(r"^(\d{4})-(\d{1,2})-?$")          # 2118-6  or trailing 2118-6-
D_MY  = re.compile(r"^-?(\d{1,2})-?/(\d{4})$")        # 6/2118 , -6/2118
D_Y   = re.compile(r"^(\d{4})$")
D_MD  = re.compile(r"^(\d{1,2})[-/](\d{1,2})$")        # month-day, NO year
NUMONLY = re.compile(r"^\d+$")
# a token is a NUMERIC date value if it is only digits + - / (no letters)
NUM_DATE_CHARS = re.compile(r"^[\d/\-]+$")

# trailing de-id group id, e.g. "Month/Day/Year 3143" -> strip " 3143"
TRAIL_ID = re.compile(r"\s+\d+\s*$")

def stem(inner):
    return TRAIL_ID.sub("", inner.strip())

# ---- 3. classifier: inner label -> fine category -----------------------
def classify(inner):
    s0 = inner.strip()
    s = s0.lower()

    # (a) NUMERIC date values -- pure digits/sep, contain no letters
    if NUM_DATE_CHARS.match(s0):
        if D_YMD.match(s0):                      return "date_ymd"
        if D_MDY.match(s0):                      return "date_mdy"
        if D_YM.match(s0):                       return "date_ym"
        if D_MY.match(s0):                       return "date_my"
        if D_Y.match(s0):                        return "date_y4"
        if D_MD.match(s0):                       return "date_md"
        if NUMONLY.match(s0):                    return "numeric_id"   # bare number id
        return "date_md"                         # other -/ combos -> keep as partial

    # (b) numeric-ID labels FIRST (before name/job) so "Job Number" != job title
    if any(k in s for k in ("numeric identifier", "medical record", "serial number",
                            "social security", "unit number", "clip number",
                            "md number", "job number", "provider number",
                            "patient number", "resident number", "attending info number")):
        return "numeric_id"

    # (c) date LABELS (textual) -> surrogate date, NOT echoed
    if "holiday" in s:                           return "datelabel_holiday"
    if "season" in s:                            return "datelabel_season"
    if "date range" in s:                        return "datelabel_range"
    if "month/day/year" in s or "year/month/day" in s: return "datelabel_full"
    if "month/year" in s:                        return "datelabel_monthyear"
    if "month/day" in s:                         return "datelabel_monthday"
    if "month" in s:                             return "datelabel_month"
    if "year" in s and "digit" in s:             return "datelabel_year"
    if s.startswith("year"):                     return "datelabel_year"

    # (d) contact
    if "telephone" in s or "fax" in s or "pager" in s: return "phone"
    if "cc contact" in s or "contact info" in s: return "name"     # a person cc'd
    if "dictator" in s:                          return "name"     # dictating clinician

    # (e) locations / orgs
    if "hospital" in s or "ward name" in s or "wardname" in s or "unit name" in s:
        return "hospital"
    if "university" in s or "college" in s:      return "org"
    if "company" in s:                           return "org"
    if "apartment address" in s or "street address" in s or "address" in s:
        return "address"
    if "location" in s:                          return "location"
    if "country" in s:                           return "country"
    if "state" in s:                             return "state"

    # (f) age
    if "age over" in s:                          return "age90"

    # (g) names -- order: initials, first, last, then generic name
    if "initial" in s:                           return "initials"
    if "first name" in s or "firstname" in s:    return "first_name"
    if "last name" in s or "lastname" in s:      return "last_name"
    if "name prefix" in s or "prefix" in s:      return "name_prefix"
    if "name" in s or "(md)" in s or " md" in s or "doctor" in s or "attending" in s:
        return "name"

    if "job" in s:                               return "job"       # actual job/occupation
    return "UNCLASSIFIED"

DATE_LABEL_CATS = {"datelabel_holiday","datelabel_season","datelabel_range",
                   "datelabel_full","datelabel_monthyear","datelabel_monthday",
                   "datelabel_month","datelabel_year"}
NUM_DATE_CATS   = {"date_ymd","date_mdy","date_ym","date_my","date_y4","date_md"}
NAME_CATS       = {"first_name","last_name","name","initials","name_prefix"}

MONTHS = ["January","February","March","April","May","June","July","August",
          "September","October","November","December"]
HOLIDAYS = ["New Year's Day","Memorial Day","Independence Day","Labor Day",
            "Thanksgiving","Christmas","Easter","Veterans Day"]
SEASONS = ["Spring","Summer","Fall","Winter"]

def seeded(note_id, inner):
    h = int(hashlib.md5(f"{note_id}|{inner}".encode()).hexdigest(), 16) % (2**31)
    f = Faker(); f.seed_instance(h); rnd = random.Random(h)
    return f, rnd

def surrogate_label_date(note_id, inner, cat, base_year):
    """Emit a plausible surrogate date for a textual date LABEL (no source digits)."""
    f, rnd = seeded(note_id, inner)
    mo = rnd.choice(MONTHS); day = rnd.randint(1, 28)
    yr = base_year + rnd.randint(-2, 0)
    if cat == "datelabel_holiday":   return rnd.choice(HOLIDAYS)
    if cat == "datelabel_season":    return f"{rnd.choice(SEASONS)} {yr}"
    if cat == "datelabel_range":     d2 = day + rnd.randint(2, 9); return f"{mo} {day}-{d2}"
    if cat == "datelabel_full":      return f"{mo} {day}, {yr}"
    if cat == "datelabel_monthyear": return f"{mo} {yr}"
    if cat == "datelabel_monthday":  return f"{mo} {day}"
    if cat == "datelabel_month":     return mo
    if cat == "datelabel_year":      return str(yr)
    return f"{mo} {day}, {yr}"

def make_surrogate(note_id, inner, cat):
    f, rnd = seeded(note_id, inner)
    if cat == "hospital":   return f.city() + rnd.choice([" General Hospital"," Medical Center"," Memorial Hospital"])
    if cat == "phone":      return f.numerify("(###) ###-####")
    if cat == "first_name": return f.first_name()
    if cat == "last_name":  return f.last_name()
    if cat == "name":       return f.name()
    if cat == "initials":   return "".join(rnd.choice("ABCDEFGHIJKLMNOPRSTW") for _ in range(rnd.randint(2,3)))
    if cat == "name_prefix":return rnd.choice(["Dr.","Mr.","Mrs.","Ms."])
    if cat == "address":    return f.street_address()
    if cat == "location":   return f.city()
    if cat == "state":      return f.state()
    if cat == "country":    return f.country()
    if cat == "age90":      return str(rnd.randint(90, 97))
    if cat == "org":        return f.company()
    if cat == "job":        return f.job()
    if cat == "numeric_id": return f.numerify("#####")
    return f.last_name()    # UNCLASSIFIED fallback still fills but is flagged

# ---- 4. fill one note ---------------------------------------------------
def note_delta(text):
    """Per-note constant backshift: bring the note's max real year down to ~2024."""
    years = [int(m.group(1)) for m in re.finditer(r"\[\*\*(\d{4})", text)]
    return (max(years) - 2024) if years else 0

def is_noid_name(inner, cat):
    """A name token the de-id tool left ungrouped (no numeric id) -> collision-prone."""
    return cat in NAME_CATS and not re.search(r"\d", inner)

def occurrence_keyable(inner, cat):
    """Occurrence-keying target: an id-less name that is NOT the index patient.

    MIMIC's 'Known lastname/firstname' slots denote the single index patient, so they must
    stay string-consistent even in occurrence mode (splitting them would give the same patient
    two different names). Generic clinician/contact slots (Doctor*, *(STitle), *(un), Name (NI))
    are genuinely ungrouped -> distinct mentions are distinct people -> safe to per-occurrence key.
    """
    return is_noid_name(inner, cat) and "known" not in inner.lower()

def date_surrogate(inner, cat, delta, base_year, note_id, intervals):
    """Deterministic surrogate for any DATE token; appends to intervals for I2 numeric dates."""
    if cat in NUM_DATE_CATS:
        if cat == "date_ymd":
            g = D_YMD.match(inner); ny = int(g.group(1)) - delta
            intervals.append((int(g.group(1)), ny)); return f"{ny}-{g.group(2)}-{g.group(3)}"
        if cat == "date_mdy":
            g = D_MDY.match(inner); ny = int(g.group(3)) - delta
            intervals.append((int(g.group(3)), ny)); return f"{g.group(1)}/{g.group(2)}/{ny}"
        if cat == "date_ym":
            g = D_YM.match(inner); ny = int(g.group(1)) - delta
            intervals.append((int(g.group(1)), ny)); return f"{ny}-{g.group(2)}"
        if cat == "date_my":
            g = D_MY.match(inner); ny = int(g.group(2)) - delta
            intervals.append((int(g.group(2)), ny)); return f"{g.group(1)}/{ny}"
        if cat == "date_y4":
            oy = int(inner); ny = oy - delta
            intervals.append((oy, ny)); return str(ny)
        return inner                       # date_md: month-day, no year -> keep verbatim
    return surrogate_label_date(note_id, inner, cat, base_year)

def fill(note_id, text, collision_mode=None):
    """Rebuild `text` with surrogates in one left-to-right pass.

    collision_mode "string"     -> per-placeholder-STRING surrogate (I1 string-consistent).
    collision_mode "occurrence" -> id-less NAME tokens keyed by (string, occurrence index)
                                    so each mention gets its own surrogate; every other token
                                    (dates, ids, id-bearing names) stays string-consistent.
    """
    mode = collision_mode or COLLISION_MODE
    delta = note_delta(text); base_year = 2024
    strmap, cats, flags = {}, Counter(), []
    intervals = []
    occ = Counter()          # per-placeholder occurrence counter (occurrence mode)
    sep_surrogates = 0       # extra distinct surrogates created by occurrence keying

    def surro_for(inner, cat):
        nonlocal sep_surrogates
        if cat in NUM_DATE_CATS or cat in DATE_LABEL_CATS:
            return date_surrogate(inner, cat, delta, base_year, note_id, intervals)
        return make_surrogate(note_id, inner, cat)

    def repl(m):
        nonlocal sep_surrogates
        ph, inner = m.group(0), m.group(1)
        cat = classify(inner)
        if ph not in strmap:                 # first time we see this string -> count once
            cats[cat] += 1
            if cat == "UNCLASSIFIED":
                flags.append(inner.strip())
        if mode == "occurrence" and occurrence_keyable(inner, cat):
            k = occ[ph]; occ[ph] += 1
            # distinct per-occurrence seed; interval-free (names carry no dates)
            sur = make_surrogate(f"{note_id}#{ph}#{k}", inner, cat)
            if ph in strmap and k >= 1:
                sep_surrogates += 1          # a mention beyond the first -> a separated identity
            strmap.setdefault(ph, sur)       # keep first as the string-anchor (for reporting)
            return sur
        if ph in strmap:
            return strmap[ph]
        sur = surro_for(inner, cat)
        strmap[ph] = sur
        return sur

    filled = PH.sub(repl, text)
    return filled, cats, flags, delta, strmap, intervals, sep_surrogates

# ---- 5. sanity checks (invariants) -------------------------------------
def sanity_check(note_id, text, filled, strmap, intervals, delta, mode=None):
    mode = mode or COLLISION_MODE
    # no raw placeholder survived
    assert "[**" not in filled, f"note {note_id}: a placeholder survived unfilled"
    # I1 determinism (both modes): re-running fill reproduces the SAME output text.
    out2 = fill(note_id, text, mode)[0]
    assert out2 == filled, f"note {note_id}: fill is non-deterministic (I1 broken, mode={mode})"
    # I1 string-consistency (string mode only): each placeholder string -> one surrogate,
    #    present in the filled text.
    if mode == "string":
        _, _, _, _, map2, _, _ = fill(note_id, text, "string")
        assert map2 == strmap, f"note {note_id}: string-consistency broken"
        for ph, sur in strmap.items():
            if sur != ph:
                assert sur in filled, f"note {note_id}: surrogate {sur!r} missing from output"
    # I2 interval preservation: every numeric full date shifted by the SAME delta.
    for oy, ny in intervals:
        assert oy - ny == delta, f"note {note_id}: interval not preserved ({oy}->{ny}, delta {delta})"
    return True

# ---- 6. run round + aggregate issue report -----------------------------
def win(t, a, b=30, f=320):
    p = t.find(a)
    return t[max(0, p-b):p+f].replace(chr(10), " ") if p >= 0 else ""

def main():
    agg = Counter(); unclassified = Counter()
    label_echo = 0     # date labels wrongly left as raw label text (should be 0)
    job_misroute = 0   # 'Job Number' tokens that became job titles (should be 0)
    noid_distinct = 0  # distinct id-less name strings (string-mode collision risk)
    noid_occ = 0       # total id-less name occurrences
    separated = 0      # extra identities separated by occurrence keying
    partial_dates = 0
    for nid, note in notes.items():
        text = note["text"]
        filled, cats, flags, delta, strmap, intervals, sep = fill(nid, text)
        sanity_check(nid, text, filled, strmap, intervals, delta)
        agg.update(cats)
        separated += sep
        for x in flags:
            unclassified[x] += 1
        # per-note token scan for residual defects + collision accounting
        seen_noid = set()
        for m in PH.finditer(text):
            inner = m.group(1); cat = classify(inner)
            if is_noid_name(inner, cat):
                noid_occ += 1
                seen_noid.add(m.group(0))
            if "job number" in inner.lower() and cat == "job":
                job_misroute += 1
        noid_distinct += len(seen_noid)
        for ph, sur in strmap.items():
            inner = PH.match(ph).group(1); cat = classify(inner)
            if cat in DATE_LABEL_CATS and re.search(r"(?i)(month|year|date range|holiday|season)", sur):
                label_echo += 1
            if cat == "date_md":
                partial_dates += 1

    print(f"\n============ CATEGORY COVERAGE ({POOLFILE}:{ROUND}, {len(notes)} notes) ============")
    for cat, n in agg.most_common():
        print(f"  {cat:20s} {n}")
    print(f"\n[flag] UNCLASSIFIED distinct label-stems: {len(unclassified)}")
    for lbl, n in unclassified.most_common(15):
        print(f"    !! {lbl!r}  x{n}")
    print(f"[flag] date-LABEL tokens echoed as raw label (want 0): {label_echo}")
    print(f"[flag] Job Number -> job title misroutes (want 0):     {job_misroute}")
    print(f"[collision] mode={COLLISION_MODE} | id-less name occurrences={noid_occ} "
          f"distinct-strings={noid_distinct} | identities separated by occurrence-keying={separated}")
    if COLLISION_MODE == "string":
        print(f"           string mode collapses {noid_occ}->{noid_distinct} surrogates "
              f"({noid_occ-noid_distinct} distinct clinicians share a fake name)")
    print(f"[flag] numeric month-day partials preserved verbatim:   {partial_dates}")
    print(f"[ok] invariants I1 ({COLLISION_MODE}-consistency) + I2 (interval-preserving backshift) asserted for all notes")

    nid, note = next(iter(notes.items()))
    text = note["text"]
    filled, cats, flags, delta, strmap, intervals, sep = fill(nid, text)
    anchor = "Admission Date" if "Admission Date" in text else text[:1]
    print(f"\n================ SAMPLE note {nid} (backshift {delta}y) ================")
    print("BEFORE:", win(text, anchor))
    print("AFTER :", win(filled, anchor))

if __name__ == "__main__":
    main()
