"""One-time NORMALIZATION preprocessing pass (see kart-methods.html).

Runs KART surrogate fill over each record and saves a `normalization.json` capturing
(a) placeholder -> surrogate and (b) the raw->filled character-interval map, so the
filled corpus is reproducible AND char-span annotations (MedDec, ap_parsing, simord,
PaniniQA) can be projected onto filled text. RAW text stays canonical for offsets.

LOCAL ONLY — reads credentialed MIMIC; `normalization*.json` is git-ignored.

Usage:
  python normalize_corpus.py --demo                       # synthetic, PHI-free
  python normalize_corpus.py --row-ids 55794 8706 34655   # real (needs NOTEEVENTS)
"""
from __future__ import annotations
import argparse
import csv
import gzip
import json
import os
import kart_mapping as km

csv.field_size_limit(10 ** 9)
DEFAULT_NOTE = os.environ.get(
    "MEDFOLLOW_NOTEEVENTS",
    os.path.join(os.path.dirname(__file__), "..", "Data", "external", "mimic", "NOTEEVENTS.csv.gz"))

DEMO = [
    ("SYN:1", "Follow up with Dr. [**Last Name (STitle) 7047**] at [**Hospital1 69**] on "
              "[**2118-6-2**]. Repeat BMP in 2 weeks. Call [**Telephone/Fax (1) 1844**]."),
    ("SYN:2", "Admission Date: [**2162-3-3**]. [**Known lastname **] seen by "
              "[**Last Name (STitle) **]. Plan: repeat chest CT in 3 months."),
]


def normalize_records(records, surrogate=km.default_surrogate) -> list[dict]:
    out = []
    for nid, text in records:
        _filled, _remap, pmap = km.fill_with_map(text, nid, surrogate)
        out.append(km.mapping_record(nid, text, pmap))
    return out


def load_from_noteevents(row_ids, note_path=DEFAULT_NOTE):
    want = set(map(str, row_ids))
    recs = {}
    with gzip.open(note_path, "rt", encoding="utf-8", newline="") as f:
        r = csv.reader(f); h = next(r); RID, TXT = h.index("ROW_ID"), h.index("TEXT")
        for row in r:
            if row[RID] in want:
                recs[row[RID]] = row[TXT]
                if len(recs) == len(want):
                    break
    return [(f"MIMIC:{rid}", recs[rid]) for rid in map(str, row_ids) if rid in recs]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="use synthetic PHI-free records")
    ap.add_argument("--row-ids", nargs="*", default=[], help="MIMIC ROW_IDs")
    ap.add_argument("--out", default="normalization.json")
    args = ap.parse_args()

    if args.demo or not args.row_ids:
        records = DEMO
    else:
        records = load_from_noteevents(args.row_ids)
    recs = normalize_records(records)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"format": "kart-mapping-v1", "records": recs}, f, indent=2)
    n_repl = sum(len(r["replacements"]) for r in recs)
    print(f"normalized {len(recs)} records, {n_repl} placeholders -> {args.out}")
    # demonstrate an offset projection on the first record
    if recs:
        rec = recs[0]
        remap = km.remap_from_record(rec)
        raw = dict(records)[rec["note_id"]]
        for probe in ("Repeat", "repeat", "Plan"):
            i = raw.find(probe)
            if i >= 0:
                print(f"  proj: raw[{i}]={probe!r} -> filled[{remap.project(i)}]")
                break


if __name__ == "__main__":
    main()
