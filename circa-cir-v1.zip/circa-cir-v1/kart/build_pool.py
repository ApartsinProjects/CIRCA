import csv, gzip, json, re, os
csv.field_size_limit(10**9)
NOTE=r"E:/Projects/Submitted/MedFollow/MedFollow/Data/external/mimic/NOTEEVENTS.csv.gz"
OUT=os.path.dirname(os.path.abspath(__file__))
PH=re.compile(r"\[\*\*(.*?)\*\*\]")
buckets={0:{},1:{},2:{},3:{}}
NEED=10
with gzip.open(NOTE,"rt",encoding="utf-8",newline="") as f:
    r=csv.reader(f); h=next(r); idx={c:i for i,c in enumerate(h)}
    RID,CAT,CD,TXT=idx["ROW_ID"],idx["CATEGORY"],idx["CHARTDATE"],idx["TEXT"]
    for row in r:
        if row[CAT]!="Discharge summary": continue
        if len(PH.findall(row[TXT]))<15: continue
        b=int(row[RID])%4
        if len(buckets[b])>=NEED: continue
        buckets[b][row[RID]]={"chartdate":row[CD],"text":row[TXT]}
        if all(len(buckets[k])>=NEED for k in buckets): break
json.dump({str(k):v for k,v in buckets.items()}, open(OUT+"/pool.json","w",encoding="utf-8"))
for k in buckets: print("round",k,"->",list(buckets[k]))
