"""Reproducible surrogate mapping + offset remap.

Two problems this solves:
1. REPRODUCIBILITY — fill is deterministic; we save the {tag -> surrogate} map so
   the exact filled corpus can be regenerated from raw MIMIC by anyone.
2. OFFSET SHIFT — several datasets (MedDec, ap_parsing, simord, PaniniQA) store
   annotations as CHARACTER SPANS into the RAW note (verified: MedDec offsets index
   raw text, with [**...**] tags before the spans). Surrogates differ in length from
   the [**...**] tags they replace, so every position after a replacement shifts.
   `Remap` projects raw offsets -> filled offsets; RAW stays canonical for offsets.

LOCAL ONLY — operates on credentialed MIMIC; mapping files are git-ignored.
"""
from __future__ import annotations
import re
import json
import hashlib
import random
from bisect import bisect_right

PH = re.compile(r"\[\*\*(.*?)\*\*\]")


class Remap:
    """Project a character position in the RAW text to the FILLED text."""
    def __init__(self, edits: list[tuple[int, int, int]]):
        # edits: (raw_start, raw_end, surrogate_len), disjoint, sorted by start
        self.edits = sorted(edits)
        self._starts = [e[0] for e in self.edits]

    def project(self, pos: int) -> int:
        delta = 0
        for (s, e, nl) in self.edits:
            if e <= pos:                       # replacement fully before pos
                delta += nl - (e - s)
            elif s < pos < e:                  # pos lands inside a replaced region
                return s + delta               # clamp to surrogate start
            else:
                break
        return pos + delta

    def project_span(self, start: int, end: int) -> tuple[int, int]:
        return self.project(start), self.project(end)


def default_surrogate(note_id: str, inner: str) -> str:
    """Deterministic placeholder surrogate (per (note_id, tag)). Kept simple here;
    the production filler is kart_improved.py — pass its fill fn via `surrogate=`."""
    from faker import Faker
    h = int(hashlib.md5(f"{note_id}|{inner}".encode()).hexdigest(), 16) % (2 ** 31)
    f = Faker(); f.seed_instance(h); rnd = random.Random(h)
    s = inner.lower()
    if "hospital" in s:
        return f.city() + " Hospital"
    if "telephone" in s or "fax" in s:
        return f.numerify("(###) ###-####")
    if "first name" in s:
        return f.first_name()
    if "last name" in s or "name" in s or "doctor" in s:
        return f.last_name()
    if re.fullmatch(r"[\d/\-]+", inner.strip()):
        return inner.strip()                   # date value: keep digits (backshift elsewhere)
    return f.word()


def fill_with_map(text: str, note_id: str, surrogate=default_surrogate):
    """Return (filled_text, Remap, placeholder_map). Same tag -> same surrogate
    (invariant I1), so replacement lengths are consistent per tag."""
    out, edits, pmap, last = [], [], {}, 0
    for m in PH.finditer(text):
        tag, inner = m.group(0), m.group(1)
        sur = pmap.get(tag)
        if sur is None:
            sur = surrogate(note_id, inner)
            pmap[tag] = sur
        out.append(text[last:m.start()])
        out.append(sur)
        edits.append((m.start(), m.end(), len(sur)))
        last = m.end()
    out.append(text[last:])
    return "".join(out), Remap(edits), pmap


def mapping_record(note_id: str, text: str, pmap: dict) -> dict:
    """Serialisable reproducibility + offset record for one note (normalization.json).

    (a) `replacements`: every char span replaced, its tag, surrogate, and BOTH the
        raw interval and the filled interval (interval -> interval).
    (b) `edits`: the compact (raw_start, raw_end, surrogate_len) triples that drive
        `Remap` to project any raw offset onto the filled text.
    (c) `placeholders`: tag -> surrogate (reproducibility; fake values, not PHI)."""
    reps, delta = [], 0
    for m in PH.finditer(text):
        tag = m.group(0)
        sur = pmap[tag]
        rs, re_ = m.start(), m.end()
        fs = rs + delta
        fe = fs + len(sur)
        reps.append({"tag": tag, "surrogate": sur, "raw": [rs, re_], "filled": [fs, fe]})
        delta += len(sur) - (re_ - rs)
    return {"note_id": note_id, "placeholders": pmap, "replacements": reps,
            "edits": [[r["raw"][0], r["raw"][1], len(r["surrogate"])] for r in reps]}


def save_mappings(path: str, records: list[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"format": "kart-mapping-v1", "records": records}, f, indent=2)


def load_mappings(path: str) -> dict:
    return json.load(open(path, encoding="utf-8"))


def remap_from_record(rec: dict) -> Remap:
    return Remap([tuple(x) for x in rec["edits"]])
