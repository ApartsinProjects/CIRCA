"""Build a FRESH 60-note pool (3 cycles x 20), disjoint from the prior 40-note pool
(pool.json) and mutually disjoint across cycles. LOCAL ONLY."""
import csv, gzip, json, re, os
csv.field_size_limit(10**9)
NOTE=r"E:/Projects/Submitted/MedFollow/MedFollow/Data/external/mimic/NOTEEVENTS.csv.gz"
OUT=os.path.dirname(os.path.abspath(__file__))
PH=re.compile(r"\[\*\*(.*?)\*\*\]")
prior=set(nid for b in json.load(open(OUT+"/pool.json",encoding="utf-8")).values() for nid in b)
NEED=60
fresh={}
with gzip.open(NOTE,"rt",encoding="utf-8",newline="") as f:
    r=csv.reader(f); h=next(r); idx={c:i for i,c in enumerate(h)}
    RID,CAT,CD,TXT=idx["ROW_ID"],idx["CATEGORY"],idx["CHARTDATE"],idx["TEXT"]
    for row in r:
        if row[CAT]!="Discharge summary": continue
        if row[RID] in prior: continue
        if len(PH.findall(row[TXT]))<15: continue
        fresh[row[RID]]={"chartdate":row[CD],"text":row[TXT]}
        if len(fresh)>=NEED: break
ids=list(fresh)
cycles={str(c):{i:fresh[i] for i in ids[c*20:(c+1)*20]} for c in range(3)}
json.dump(cycles, open(OUT+"/pool_cycles.json","w",encoding="utf-8"))
for c in range(3):
    cset=list(cycles[str(c)])
    print(f"cycle {c}: {len(cset)} notes  ids {cset[0]}..{cset[-1]}")
# disjointness asserts
allc=[set(cycles[str(c)]) for c in range(3)]
assert not (allc[0]&allc[1]) and not (allc[0]&allc[2]) and not (allc[1]&allc[2]), "cycles overlap"
assert not (set(ids)&prior), "overlap with prior pool"
print("disjoint from prior-40 and across cycles: OK ; total fresh:",len(ids))
