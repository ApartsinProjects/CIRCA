"""Materialize the KART surrogate fill ONCE per MIMIC record and reuse it for every
dataset that references that record.

The surrogate fill is seeded by the note key, so the SAME MIMIC note must be filled
under ONE canonical key ('MIMIC:<row_id>') — never a dataset-prefixed key — or CLIP,
MedDec, ap_parsing etc. would get DIFFERENT surrogate text (and offsets) for the same
record, breaking cross-dataset consistency. Result is cached on disk so it is computed
once and read back identically by all datasets/runs.

LOCAL ONLY — reads credentialed MIMIC; the cache is git-ignored (lives under var/).
"""
from __future__ import annotations
import json
import pathlib
import kart_mapping as km


def canonical_key(row_id) -> str:
    return f"MIMIC:{row_id}"


def filled_note(row_id, raw_text, cache_dir, surrogate=km.default_surrogate):
    """Return the KART-filled note for a MIMIC ROW_ID, materializing + caching on first
    use. Deterministic and dataset-independent: keyed by the canonical MIMIC row id, so
    every dataset referencing this record sees byte-identical filled text and offsets."""
    row_id = str(row_id)
    cache_dir = pathlib.Path(cache_dir)
    p = cache_dir / f"{row_id}.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))["filled"]
    key = canonical_key(row_id)
    filled, _remap, pmap = km.fill_with_map(raw_text, key, surrogate)
    record = km.mapping_record(key, raw_text, pmap)     # placeholders + raw->filled offset map
    cache_dir.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"row_id": row_id, "key": key, "filled": filled,
                             "mapping": record}), encoding="utf-8")
    return filled


def mapping_for(row_id, cache_dir) -> dict | None:
    """Return the stored normalization record (offset map) for a materialized note, or
    None if it has not been filled yet. Used to project char-span annotations onto the
    filled text."""
    p = pathlib.Path(cache_dir) / f"{row_id}.json"
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8")).get("mapping")
