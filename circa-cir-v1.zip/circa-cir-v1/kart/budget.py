#!/usr/bin/env python
"""Estimate token workload + budget for annotating the union of MIMIC-derived
annotated notes (CLIP + MedDec + ap_parsing + PaniniQA)."""
import csv, gzip, glob, os, statistics as st
csv.field_size_limit(10**9)
EXT = r"E:/Projects/Submitted/MedFollow/MedFollow/Data/external"
NOTE = EXT + "/mimic/NOTEEVENTS.csv.gz"

def clip():
    d=glob.glob(EXT+"/clip/clip-*/")[0]; s=set()
    for p in ("train_ids.csv","val_ids.csv","test_ids.csv"): s|={l.strip() for l in open(d+p) if l.strip()}
    return s
def ap():
    return {str(r["note_id"]).strip() for r in csv.DictReader(open(EXT+"/ap_parsing/ap_annotations.csv"))}
def meddec():
    return {os.path.basename(p)[:-5].split("_")[2] for p in glob.glob(EXT+"/meddec/meddec-*/data/*.json")}
def panini():
    return {os.path.basename(p).split("-")[0] for p in glob.glob(EXT+"/paniniqa/data/annotated_dataset/annotated_files/*_evt.csv")}
ids = clip()|ap()|meddec()|panini()
print(f"union annotated notes: {len(ids)}")

lens=[]
with gzip.open(NOTE,"rt",encoding="utf-8",newline="") as f:
    r=csv.reader(f); h=next(r); RID=h.index("ROW_ID"); TXT=h.index("TEXT")
    for row in r:
        if row[RID] in ids: lens.append(len(row[TXT]))
tok=[c/4 for c in lens]                                   # ~4 chars/token
N=len(tok); total_note_tok=sum(tok)
print(f"matched {N} notes | chars avg={st.mean(lens):.0f} median={st.median(lens):.0f} max={max(lens)}")
print(f"note tokens: avg={st.mean(tok):.0f} median={st.median(tok):.0f} total={total_note_tok/1e6:.2f}M")

# ---- budget model -------------------------------------------------------
S      = 6000          # static prefix (schema+guidelines+8 few-shot+crosswalk), cached
OVH    = 400           # per-note dynamic overhead (raw source annotation + candidate map + tail)
OUT    = 800           # avg output tokens (JSON intents) per annotation
A      = 2             # independent annotators
ADJ    = 0.30          # fraction needing adjudication (3rd call)
dyn = total_note_tok + N*OVH                              # dynamic input across all notes (1 annotator)

print("\n================ TOKEN BUDGET (whole corpus) ================")
def M(x): return f"{x/1e6:.2f}M"
# NAIVE: full prefix re-sent every call
naive_in  = A*(N*S + dyn) + ADJ*N*(S + (total_note_tok/N+OVH) + 2*OUT)
naive_out = A*N*OUT + ADJ*N*OUT
# CACHED: prefix is cache-read (~10% cost); count separately
prefix_calls = A*N + int(ADJ*N)
cached_fresh_in = A*dyn + ADJ*(total_note_tok + N*OVH + 2*N*OUT)   # non-prefix input
cached_prefix_read = prefix_calls*S
print(f"annotator calls={A*N}  adjudicator calls≈{int(ADJ*N)}  total≈{prefix_calls}")
print(f"NAIVE  input≈{M(naive_in)}  output≈{M(naive_out)}")
print(f"CACHED fresh-input≈{M(cached_fresh_in)}  + prefix-cache-reads≈{M(cached_prefix_read)} (billed ~10%)  output≈{M(naive_out)}")

# ---- cost framings (approx, VERIFY rates) -------------------------------
print("\n---- if Bedrock hosted (illustrative rate $0.72/M in, $0.72/M out) ----")
rate_in=rate_out=0.72
naive_cost = naive_in/1e6*rate_in + naive_out/1e6*rate_out
cached_cost = (cached_fresh_in/1e6 + cached_prefix_read/1e6*0.1)*rate_in + naive_out/1e6*rate_out
print(f"  naive  ≈ ${naive_cost:.0f}   cached ≈ ${cached_cost:.0f}")
print("\n---- if self-hosted open model (GPU-hours) ----")
tot_tok = cached_fresh_in + cached_prefix_read + naive_out
for name,tps in [("1xA100 ~2.5k tok/s",2500),("1xH100 ~5k tok/s",5000)]:
    hrs=tot_tok/tps/3600
    print(f"  {name}: {tot_tok/1e6:.1f}M tok -> {hrs:.1f} GPU-h")
