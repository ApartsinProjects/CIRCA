# MedFollow-CIR: dataset card

Clinical Intent Extraction (CIE) annotations in the Clinical Intent Representation (CIR),
harmonizing five source corpora. Every record carries `source_corpus` (provenance to the
originating dataset) and a `note_ref` to the original note.

## Two release layers (MIMIC-III DUA compliance)

- **public/aci_bench_cir.jsonl** — SIMORD/ACI-Bench (CDLA-Permissive-2.0, simulated, no PHI).
  Full CIR records WITH note text and verbatim provenance spans. Redistributable.
- **credentialed/** — MIMIC-III-derived annotations. Per the PhysioNet/MIMIC-III DUA, no
  MIMIC clinical text is redistributed. Annotations are STAND-OFF: a `row_id`, character
  offsets into the canonical KART-filled note, and a `span_sha256`. Reconstruct the text
  with `rebuild.py` and your own credentialed MIMIC-III copy.

## Hydration

    python rebuild.py --noteevents /path/NOTEEVENTS.csv.gz \
        --annotations credentialed/annotations_cir.jsonl \
        --mappings credentialed/kart_mappings.jsonl \
        --out hydrated_mimic_cir.jsonl

`kart_mappings.jsonl` holds only de-identification placeholder surrogates and raw offsets;
it contains no MIMIC clinical text. `rebuild.py` verifies each reconstructed note against
`filled_sha256` before attaching spans.

## Counts (this build)

{
 "mimic_intents": 8568,
 "located": 9012,
 "mimic_notes": 636,
 "unlocated": 97,
 "public_intents": 1443,
 "public_notes": 193
}

`located`/`unlocated` count provenance spans found verbatim in the filled note; unlocated
spans (model paraphrase) carry a null offset and no recoverable text, but retain the
structured label and `span_sha256`.

## Provenance tiers

Records are `consensus_silver` (all models agreed, routed to auto-accept) or
`unresolved_silver` (models disagreed, routed to human adjudication). Human-adjudicated
gold is added by the validation pass; no record is labeled gold until a human inspects it.
