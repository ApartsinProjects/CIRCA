"""Hydrate the credentialed MedFollow-CIR layer from YOUR OWN MIMIC-III NOTEEVENTS.

This attaches text to the stand-off annotations. It reads NO text from the release
(there is none); it reconstructs the canonical KART-filled note from your credentialed
MIMIC copy using the published mapping, verifies the SHA-256, then slices each span.

Usage:
  python rebuild.py --noteevents /path/NOTEEVENTS.csv.gz \
      --annotations credentialed/annotations_cir.jsonl \
      --mappings credentialed/kart_mappings.jsonl \
      --out hydrated_mimic_cir.jsonl
"""
import sys, csv, gzip, json, hashlib, argparse

def sha(s): return hashlib.sha256(s.encode("utf-8")).hexdigest()

def apply_mapping(raw, mp):
    """Reconstruct the canonical filled note from raw MIMIC text + published KART mapping.
    Replaces each de-identification placeholder span (raw offsets) with its surrogate,
    right-to-left so earlier offsets stay valid. No MIMIC text ships in the mapping."""
    reps = sorted(mp.get("replacements", []), key=lambda r: r["raw"][0], reverse=True)
    out = raw
    for r in reps:
        s, e = r["raw"]; out = out[:s] + r["surrogate"] + out[e:]
    return out

def load_notes(path, ids):
    ids = set(map(str, ids)); texts = {}
    op = gzip.open if path.endswith(".gz") else open
    with op(path, "rt", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            rid = row.get("ROW_ID") or row.get("row_id")
            if rid in ids:
                texts[rid] = row.get("TEXT") or row.get("text") or ""
    return texts

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--noteevents", required=True)
    ap.add_argument("--annotations", required=True)
    ap.add_argument("--mappings", required=True)
    ap.add_argument("--out", default="hydrated_mimic_cir.jsonl")
    a = ap.parse_args()
    mappings = {}
    for line in open(a.mappings, encoding="utf-8"):
        if line.strip():
            m = json.loads(line); mappings[str(m["row_id"])] = m["mapping"]
    anns = [json.loads(l) for l in open(a.annotations, encoding="utf-8") if l.strip()]
    ids = {str(r["note_ref"]["row_id"]) for r in anns}
    raw = load_notes(a.noteevents, ids)
    filled = {}
    miss, bad = 0, 0
    for rid in ids:
        if rid not in raw:
            miss += 1; continue
        f = apply_mapping(raw[rid], mappings[rid])
        filled[rid] = f
    n = 0
    with open(a.out, "w", encoding="utf-8") as out:
        for r in anns:
            rid = str(r["note_ref"]["row_id"])
            f = filled.get(rid)
            if f is None:
                continue
            if sha(f) != r["note_ref"]["filled_sha256"]:
                bad += 1; continue
            for p in r.get("provenance", []):
                if p.get("char_start") is not None:
                    p["span"] = f[p["char_start"]:p["char_end"]]
            tg = r.get("target", {})
            if tg.get("char_start") is not None:
                tg["text"] = f[tg["char_start"]:tg["char_end"]]
            out.write(json.dumps(r) + "\n"); n += 1
    print(f"hydrated {n} annotations | notes missing from your MIMIC: {miss} | SHA mismatches: {bad}")
    if bad:
        print("SHA mismatches mean your MIMIC text differs from the canonical source; "
              "check MIMIC-III version (v1.4 expected).")

if __name__ == "__main__":
    main()
