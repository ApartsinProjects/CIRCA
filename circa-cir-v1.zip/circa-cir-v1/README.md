# CIRCA: Clinical Intent Representation, Cross-corpus Annotations

CIRCA is a dataset of **clinical intents** annotated in the Clinical Intent
Representation (CIR), harmonized across five heterogeneous source corpora. This deposit
publishes **only the annotations, the value mappings, and the code** needed to
reconstruct the dataset. It contains **no original clinical text** from any restricted
source.

- **10,011 CIR intents** over 829 notes with recoverable text (636 MIMIC-III + 193
  ACI-Bench), from CLIP, MedDec, ap_parsing, PaniniQA (all MIMIC-III derived) and
  SIMORD / ACI-Bench (public, simulated).
- Each intent carries up to 11 content fields plus two novel axes, `request_intent`
  (clinical authority) and `modality` (strength), adapted from FHIR R4 `RequestIntent`.

## What this deposit contains, and what it deliberately does not

| Included | Not included |
|---|---|
| CIR annotations (labels, fields, both novel axes) | Any MIMIC-III clinical note text |
| Character offsets + SHA-256 into the canonical note | Verbatim provenance spans for MIMIC-derived notes |
| KART value mappings (synthetic surrogates + offsets) | The rater workbooks (they contain surrogate-filled note text; kept local) |
| ACI-Bench records **with** text (public, simulated) | Raw source corpora |
| The KART code and a hydration script | Any protected health information |

Only labels, annotations, and mappings are published. This is a deliberate compliance
boundary, not an omission: see **Data provenance and compliance** below.

## Layout

```
public/aci_bench_cir.jsonl        ACI-Bench (SIMORD): full CIR records WITH note text
                                  and verbatim provenance spans. Public, redistributable
                                  (CDLA-Permissive-2.0, simulated, no PHI).
credentialed/
  annotations_cir.jsonl           MIMIC-derived CIR records as STAND-OFF annotations:
                                  a row_id, character offsets into the canonical
                                  KART-filled note, and a span SHA-256. No MIMIC text.
  kart_mappings.jsonl             Per note: the KART de-identification placeholder ->
                                  synthetic-surrogate map with raw/filled offsets, so a
                                  credentialed user reconstructs the exact canonical note.
                                  Contains no MIMIC clinical text.
  note_index.csv                  row_id -> contributing corpora, note type, filled SHA.
rebuild.py                        Hydrator: with your own credentialed MIMIC-III
                                  NOTEEVENTS, reconstructs each note and re-attaches text
                                  to the stand-off annotations.
kart/                             The KART de-identification / surrogate-fill code that
                                  produced the canonical notes and the mappings.
code/                             The deterministic FHIR R4 mapper (cir_to_fhir.py), the
                                  source-to-CIR crosswalks (crosswalk.py), and the reference
                                  benchmark evaluator (tools/gold_eval.py) implementing the
                                  Section 6 matching rule, with their import closure. See
                                  code/README.md.
schema/cir_vocab.json             Controlled vocabularies for the CIR fields and axes.
DATASHEET.md, LICENSES.md         Dataset card and per-layer licensing.
checksums.sha256                  SHA-256 of every file in this bundle.
```

## Reconstructing the full dataset (credentialed users)

The MIMIC-derived layer is published stand-off. To attach text you supply your own
PhysioNet-credentialed MIMIC-III copy; nothing here substitutes for that access.

```bash
python rebuild.py \
    --noteevents /path/to/NOTEEVENTS.csv.gz \
    --annotations credentialed/annotations_cir.jsonl \
    --mappings    credentialed/kart_mappings.jsonl \
    --out         hydrated_mimic_cir.jsonl
```

`rebuild.py` reconstructs each canonical note by applying the published KART mapping to
your raw MIMIC text, verifies it against `filled_sha256`, then slices each span by its
offsets. It reads no text from this deposit (there is none to read). The public
ACI-Bench layer is already complete and needs no hydration.

MIMIC-III v1.4 is expected. A SHA mismatch means your source text differs from the
canonical version; `rebuild.py` reports the count and skips those notes rather than
emitting unverified spans.

## Data provenance and compliance

The annotation pipeline used a large language model to produce candidate CIR labels,
which were then routed by inter-model agreement and, for the core, adjudicated by trained
annotators. To process restricted clinical text under this pipeline, two controls were
applied:

1. **Business Associate Agreement (BAA).** Model inference ran through AWS Bedrock under
   a signed BAA covering the handling of protected health information, so clinical text
   was processed only within the agreement's terms.
2. **Zero-retention inference.** Bedrock was used in a configuration where prompts and
   completions are not retained or used for model training, so no clinical text persisted
   in the model provider's systems beyond the request.

These controls governed how the annotations were *produced*. They are separate from, and
do not substitute for, the source-corpus data use agreements that govern the *text*: the
PhysioNet / MIMIC-III DUA still applies to any MIMIC text a user reconstructs, and this
deposit never redistributes that text. The BAA on the pipeline and the DUA on the source
are independent obligations.

**KART** (Keep All Realistic Transformations) is the de-identification and surrogate-fill
step. We modified it for this setting so that every substitution is recorded as a
reversible mapping (placeholder token -> synthetic surrogate, with raw and filled character
offsets) rather than an in-place edit. This is what makes the stand-off release exact: the
mapping reconstructs the canonical filled note byte-for-byte from a credentialed user's own
MIMIC copy, and the mapping itself carries only synthetic surrogates and integer offsets,
never clinical content. The modified KART code is in `kart/`.

## Citation

See `CITATION.cff`. Corresponding author: Yehudit Aperstein (apersteiny@afeka.ac.il).
